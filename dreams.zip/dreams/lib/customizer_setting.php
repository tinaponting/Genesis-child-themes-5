<?php
/*========================== CUSTOMIZER ========================== */
function ss_customizer( $wp_customize ) {
		// Section : Header Area
		$wp_customize->add_section( 'skyandstars_headerlogo', array(
			'title' => __( 'Header Size', 'skyandstars' ),
			'priority' => 60,
		) );

		// Section : Theme Color
		$wp_customize->add_section( 'skyandstars_theme_colors', array(
			'title' => __( 'Theme Color', 'skyandstars' ),
			'priority' => 70,
		) );

		// SECTION
		$wp_customize->add_section( 'skyandstars_theme_colors', array(
			'title' => __( 'Theme Color', 'skyandstars' ),
			'priority' => 50,
		) );
	
	
		//SETTING
		
		// Setting : Header Area Height
		$wp_customize->add_setting( 'header_logo_height' , array(
			'default' => '180',
			'transport'   => 'refresh',
			'sanitize_callback' => 'absint'
		) );
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'header_logo_height', array(
			'type' => 'number',
			'description' => __( 'Resize your Header height (Default is 180 pixels, maximum 300 pixels.).', 'skyandstars' ),
			'label' => 'Header logo height',
			'section' => 'skyandstars_headerlogo',
			'settings' => 'header_logo_height',
		) ) );

		// Background Color
		$wp_customize->add_setting( 'bgx_color' , array(
			'default' => '#fbf4f4',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'bgx_color', array(
			'label' => 'Theme Background Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'bgx_color',
		) ) );

		// Text Color
		$wp_customize->add_setting( 'text_color' , array(
			'default' => '#333333',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'text_color', array(
			'label' => 'Text Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'text_color',
		) ) );
		
		// Post Title Color
		$wp_customize->add_setting( 'posttitle_color' , array(
			'default' => '#333333',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'posttitle_color', array(
			'label' => 'Post Title Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'posttitle_color',
		) ) );

		// Theme Link Color
		$wp_customize->add_setting( 'content_link_color' , array(
			'default' => '#a29c90',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'content_link_color', array(
			'label' => 'Content Link Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'content_link_color',
		) ) );
		
		// Theme Link Hover Color
		$wp_customize->add_setting( 'link_hvrcolor' , array(
			'default' => '#edb0b0',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'link_hvrcolor', array(
			'label' => 'Link Hover Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'link_hvrcolor',
		) ) );
		
		// Category Post Link Color
		$wp_customize->add_setting( 'catlink_color' , array(
			'default' => '#5d5d5d',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'catlink_color', array(
			'label' => 'Category Link Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'catlink_color',
		) ) );

		// Category Post Link Hover Color
		$wp_customize->add_setting( 'catlinkhvr_color' , array(
			'default' => '#ffffff',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'catlinkhvr_color', array(
			'label' => 'Category Link Hover Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'catlinkhvr_color',
		) ) );

		// Category Background
		$wp_customize->add_setting( 'catbg_color' , array(
			'default' => '#ffffff',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'catbg_color', array(
			'label' => 'Category Background Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'catbg_color',
		) ) );

		// Category Background HOVER
		$wp_customize->add_setting( 'catbghvr_color' , array(
			'default' => '#edb0b0',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'catbghvr_color', array(
			'label' => 'Category Background Hover Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'catbghvr_color',
		) ) );
		
		
		// NAVTAB BG Color
		$wp_customize->add_setting( 'menu_bg_color' , array(
			'default' => '#ffffff',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'menu_bg_color', array(
			'label' => 'Menu Background Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'menu_bg_color',
		) ) );
		// NAVTAB Link Color
		$wp_customize->add_setting( 'menu_link_color' , array(
			'default' => '#333333',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'menu_link_color', array(
			'label' => 'Menu Text Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'menu_link_color',
		) ) );
		// NAVTAB Link Hover Color
		$wp_customize->add_setting( 'menu_link_hvrcolor' , array(
			'default' => '#656460',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'menu_link_hvrcolor', array(
			'label' => 'Menu Text Hover Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'menu_link_hvrcolor',
		) ) );
		
		// BUTTON Color
		$wp_customize->add_setting( 'btn_color' , array(
			'default' => '#000000',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'btn_color', array(
			'label' => 'Button Background Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'btn_color',
		) ) );
		
		// Button Text Color
		$wp_customize->add_setting( 'btn_txt_color' , array(
			'default' => '#ffffff',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'btn_txt_color', array(
			'label' => 'Button Text Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'btn_txt_color',
		) ) );
		
		// BUTTON HOVER Color
		$wp_customize->add_setting( 'btn_hvrcolor' , array(
			'default' => '#edb0b0',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'btn_hvrcolor', array(
			'label' => 'Button Hover Background Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'btn_hvrcolor',
		) ) );
		
		
		// Button Text Hover Color
		$wp_customize->add_setting( 'btntxt_hvrcolor' , array(
			'default' => '#ffffff',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'btntxt_hvrcolor', array(
			'label' => 'Button Text Hover Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'btntxt_hvrcolor',
		) ) );
		
		// Widget Text Color
		$wp_customize->add_setting( 'widgettxt_color' , array(
			'default' => '#5f5f5f',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'widgettxt_color', array(
			'label' => 'Widget Text Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'widgettxt_color',
		) ) );

		// Mailchimp subs box
		$wp_customize->add_setting( 'mchimp_box' , array(
			'default' => '#f2e7e7',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'mchimp_box', array(
			'label' => 'Mailchimp Widget box Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'mchimp_box',
		) ) );
}
add_action( 'customize_register', 'ss_customizer' );
?>