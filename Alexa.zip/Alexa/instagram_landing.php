<?php
/**
 * Template Name: Instagram Landing
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that other 'pages' on your WordPress site will use a different template. 
 *
 * @author Eclair Designs
 * @package Chloe
 * 
 */

//* Add Instagram page body class to the head.
add_filter( 'body_class', 'custom_instagram_menu_add_body_class' );
function custom_instagram_menu_add_body_class( $classes ) {

	$classes[] = 'poppy-instagram';

	return $classes;

}

//* Force full width content layout
add_filter( 'genesis_site_layout', '__genesis_return_full_width_content' );
remove_action( 'genesis_header', 'genesis_do_nav' );
remove_action( 'genesis_header', 'genesis_header_markup_open', 5 );
remove_action( 'genesis_header', 'genesis_header_markup_close', 15 );
remove_action( 'genesis_before_header', 'genesis_do_nav' );
remove_action('genesis_before_footer', 'ed_ig', 9 );
remove_action('genesis_before_footer', 'alexa_posts', 11 );
remove_action( 'genesis_footer', 'eclairdesigns_footer' );
remove_action( 'genesis_header', 'poppy_offscreen_output' );
remove_action('genesis_before_footer', 'ed_subscribe', 8 );
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );
remove_action( 'genesis_before_footer', 'genesis_footer_widget_areas' );
remove_action( 'genesis_footer', 'sp_custom_footer' );
remove_action( 'genesis_footer', 'genesis_footer_markup_open', 5 );
remove_action( 'genesis_footer', 'genesis_do_footer' );
remove_action( 'genesis_footer', 'genesis_footer_markup_close', 15 );
remove_action( 'genesis_before_footer', 'ed_before_footer', 9 );
remove_action( 'genesis_entry_footer', 'single_post_social_share' );
remove_action( 'genesis_before_header', 'eclair_social_icons', 10 );

unregister_sidebar( 'header-right' );
genesis();