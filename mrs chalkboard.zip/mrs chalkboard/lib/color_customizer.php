<?php

//* Add Color Options in Customizer
function mrs_customize_register( $wp_customize ) {
$colors = array();
	$colors[] = array(
  		'slug'=>'site_title_color', 
  		'default' => '#f5f5f5',
  		'label' => __('Site Title', 'mrs')
);
	$colors[] = array(
  		'slug'=>'tagline_color', 
  		'default' => '#f5f5f5',
  		'label' => __('Tagline', 'mrs')
);
	$colors[] = array(
  		'slug'=>'social_media_icons_color', 
  		'default' => '#484848',
  		'label' => __('Social Media Icons', 'mrs')
);
	$colors[] = array(
  		'slug'=>'social_media_hover_color', 
  		'default' => '#a1a1a1',
  		'label' => __('Social Media Icons Hover Color', 'mrs')
);

	$colors[] = array(
  		'slug'=>'nav_menu_color', 
  		'default' => '#f5f5f5',
  		'label' => __('Nav Menu Color', 'mrs')
);

	$colors[] = array(
  		'slug'=>'nav_border_color', 
  		'default' => '#f5f5f5',
  		'label' => __('Nav Border Color', 'mrs')
);

	$colors[] = array(
  		'slug'=>'post_title_color', 
  		'default' => '#484848',
  		'label' => __('Post Title Color', 'mrs')
);

	$colors[] = array(
  		'slug'=>'post_title_hover_color', 
  		'default' => '#a1a1a1',
  		'label' => __('Post Title Hover Color', 'mrs')
);

	$colors[] = array(
  		'slug'=>'body_font_color', 
  		'default' => '#484848',
  		'label' => __('Body Font Color', 'mrs')
);		

	$colors[] = array(
  		'slug'=>'link_color', 
  		'default' => '#a1a1a1',
  		'label' => __('Link Color', 'mrs')
);

	$colors[] = array(
  		'slug'=>'sidebar_title_color', 
  		'default' => '#f5f5f5',
  		'label' => __('Widget Title Color', 'mrs')
);

	$colors[] = array(
  		'slug'=>'continue_reading_color', 
  		'default' => '#484848',
  		'label' => __('Continue Reading Color', 'mrs')
);

	$colors[] = array(
  		'slug'=>'subscribe_color', 
  		'default' => '#f5f5f5',
  		'label' => __('Subscribe Paragraph Color', 'mrs')
);

	$colors[] = array(
  		'slug'=>'subscribe_submit_color', 
  		'default' => '#f5f5f5',
  		'label' => __('Subscribe Submit Button Color', 'mrs')
);

	$colors[] = array(
  		'slug'=>'post_date_color', 
  		'default' => '#a1a1a1',
  		'label' => __('Post Date Color', 'mrs')
);

	$colors[] = array(
  		'slug'=>'share_buttons_font_color', 
  		'default' => '#484848',
  		'label' => __('Share Buttons Font', 'mrs')
);

	$colors[] = array(
  		'slug'=>'share_buttons_background_color', 
  		'default' => '#f5f5f5',
  		'label' => __('Share Buttons Background', 'mrs')
);

	$colors[] = array(
  		'slug'=>'pagination_font_color', 
  		'default' => '#484848',
  		'label' => __('Pagination Font Color', 'mrs')
);

	$colors[] = array(
  		'slug'=>'pagination_background_color', 
  		'default' => '#f5f5f5',
  		'label' => __('Pagination Background Color', 'mrs')
);

foreach( $colors as $color ) {

// Add color settings
$wp_customize->add_setting( $color['slug'], array(
      	'default' => $color['default'],
      	'type' => 'option', 
      	'capability' => 
      	'edit_theme_options'
) );

// Add color controls
$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $color['slug'], array('label' => $color['label'], 
      	'section' => 'colors',
      	'settings' => $color['slug'])
) );
}
}
add_action( 'customize_register', 'mrs_customize_register' );


function mrs_customizer_register() {
	$site_title_color = get_option( 'site_title_color' );
	$tagline_color = get_option( 'tagline_color' );
	$social_media_icons_color = get_option( 'social_media_icons_color' );
	$social_media_hover_color = get_option( 'social_media_hover_color' );
	$nav_menu_color = get_option( 'nav_menu_color' );
	$nav_border_color = get_option( 'nav_border_color' );
	$post_title_color = get_option( 'post_title_color' );
	$post_title_hover_color = get_option( 'post_title_hover_color' );
	$body_font_color = get_option( 'body_font_color' );
	$link_color = get_option( 'link_color' );
	$sidebar_title_color = get_option( 'sidebar_title_color' );
	$continue_reading_color = get_option( 'continue_reading_color' );
	$subscribe_color = get_option( 'subscribe_color' );
	$subscribe_submit_color = get_option( 'subscribe_submit_color' );
	$post_date_color = get_option( 'post_date_color' );
	$share_buttons_font_color = get_option( 'share_buttons_font_color' );
	$share_buttons_background_color = get_option( 'share_buttons_background_color' );
	$pagination_font_color = get_option( 'pagination_font_color' );
	$pagination_background_color = get_option( 'pagination_background_color' );
	
	if ( $site_title_color != '#f5f5f5' || $tagline_color != '#f5f5f5' || $social_media_icons_color != '#484848' || $social_media_hover_color != '#a1a1a1' || $nav_menu_color != '#f5f5f5' || $nav_border_color != '#f5f5f5' || $post_title_color != '#484848' || $post_title_hover_color != '#a1a1a1' || $body_font_color != '#484848' || $link_color != '#a1a1a1' || $sidebar_title_color != '#f5f5f5' || $continue_reading_color != '#484848' || $subscribe_color != '#f5f5f5' || $subscribe_submit_color != '#f5f5f5' || $post_date_color != '#a1a1a1' || $share_buttons_font_color != '#484848' || $share_buttons_background_color != '#f5f5f5' || $pagination_font_color != '#484848' || $pagination_background_color != '#f5f5f5' ) : 
	?>
		<style type="text/css">
				
			.site-title a, .site-title a:hover {
				color: <?php echo $site_title_color; ?>;
			}

			.site-description {
				color: <?php echo $tagline_color; ?>;
			}

			.simple-social-icons .social-bloglovin a, .simple-social-icons .social-dribbble a,
			.simple-social-icons .social-email a, .simple-social-icons .social-facebook a,
			.simple-social-icons .social-flickr a, .simple-social-icons .social-github a,
			.simple-social-icons .social-gplus a, .simple-social-icons .social-instagram a,
			.simple-social-icons .social-linkedin a, .simple-social-icons .social-pinterest a,
			.simple-social-icons .social-rss a, .simple-social-icons .social-stumbleupon a,
			.simple-social-icons .social-tumblr a, .simple-social-icons .social-twitter a,
			.simple-social-icons .social-vimeo a, .simple-social-icons .social-youtube a {
    				color: <?php echo $social_media_icons_color; ?> !important;
			}

			.simple-social-icons .social-bloglovin a:hover, .simple-social-icons .social-dribbble a:hover,
			.simple-social-icons .social-email a:hover, .simple-social-icons .social-facebook a:hover,
			.simple-social-icons .social-flickr a:hover, .simple-social-icons .social-github a:hover,
			.simple-social-icons .social-gplus a:hover, .simple-social-icons .social-instagram a:hover,
			.simple-social-icons .social-linkedin a:hover, .simple-social-icons .social-pinterest a:hover,
			.simple-social-icons .social-rss a:hover, .simple-social-icons .social-stumbleupon a:hover,
			.simple-social-icons .social-tumblr a:hover, .simple-social-icons .social-twitter a:hover,
			.simple-social-icons .social-vimeo a:hover, .simple-social-icons .social-youtube a:hover {
    				color: <?php echo $social_media_hover_color; ?> !important;
			}

			.genesis-nav-menu a, .genesis-nav-menu .current-menu-item > a, 
			.genesis-nav-menu .sub-menu a, .genesis-nav-menu > li:hover .sub-menu a {
				color: <?php echo $nav_menu_color; ?>;
			}

			.nav-primary, .genesis-nav-menu .sub-menu a, .genesis-nav-menu > li:hover .sub-menu a {
				border-color: <?php echo $nav_border_color; ?>;
			}

			.entry-title a, .sidebar .widget-title a {
				color: <?php echo $post_title_color; ?>;
			}

			.entry-title a:hover {
				color: <?php echo $post_title_hover_color; ?>;
			}

			body, blockquote {
				color: <?php echo $body_font_color; ?>;
			}

			a, .site-footer a {
				color: <?php echo $link_color; ?>;
			}

			.sidebar .widget h4, .footer-widgets .widget-title {
				color: <?php echo $sidebar_title_color; ?>;
			}

			.mrs-chalkboard-home a.more-link, a.more-link {
				color: <?php echo $continue_reading_color; ?>;
			}

			.enews p {
				color: <?php echo $subscribe_color; ?>;
			}

			.enews-widget input[type="submit"] {
				color: <?php echo $subscribe_submit_color; ?>;
				border-color: <?php echo $subscribe_submit_color; ?>;
			}

			.entry-time {
				color: <?php echo $post_date_color; ?>;
			}

			div.sharedaddy h3.sd-title, .content a.sd-button > span, .sd-content ul li a.sd-button::before {
				color: <?php echo $share_buttons_font_color; ?> !important;
			}

			#sharing_email .sharing_send, .sd-content ul li .option a.share-ustom, .sd-content ul li a.sd-button, 
			.sd-content ul li.advanced a.share-more, .sd-content ul li.preview-item div.option.option-smart-off a, 
			.sd-social-icon .sd-content ul li a.sd-button, .sd-social-icon-text .sd-content ul li a.sd-button, 
			.sd-social-official .sd-content > ul > li .digg_button > a, .sd-social-official .sd-content > ul > li > a.sd-button,
			.sd-social-text .sd-content ul li a.sd-button {
				background-color: <?php echo $share_buttons_background_color; ?> !important;
			}

			.archive-pagination li a, .archive-pagination li.active a {
				color: <?php echo $pagination_font_color; ?>;
			}

			.archive-pagination .pagination-next > a, .archive-pagination .pagination-previous > a,
			.archive-pagination li a {
				background-color: <?php echo $pagination_background_color; ?>;
			}
	
		</style>
	<?php
	endif;
}
add_action( 'wp_head', 'mrs_customizer_register' );