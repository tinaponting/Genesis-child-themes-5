<?php
//* Start the engine
require_once( get_template_directory() . '/lib/init.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'Liana' );
define( 'CHILD_THEME_VERSION', '1.0' );

//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );

//* Add Viewport meta tag for mobile browsers
add_action( 'genesis_meta', 'sample_viewport_meta_tag' );
function sample_viewport_meta_tag() {
	echo '<meta name="viewport" content="width=device-width, initial-scale=1.0"/>';
}

//* Add support for custom background
add_theme_support( 'custom-background' );

//* Add support for custom header
add_theme_support( 'custom-header', array(
	'flex-height'     => true,
	'flex-width'      => true,
	'header-selector' => '.site-title a',
	'header-text'     => false,
	'height'          => 400,
	'width'           => 600,
) );

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//* Remove comment form allowed tags
add_filter( 'comment_form_defaults', 'sp_remove_comment_form_allowed_tags' );
function sp_remove_comment_form_allowed_tags( $defaults ) {
 
	$defaults['comment_notes_after'] = '';
	return $defaults;
}

//* Add Post categories above Post title on single Posts
add_action ( 'genesis_entry_header', 'eclair_category_name', 9 );
function eclair_category_name() {

	if ( !is_page() && !is_category() && !is_archive() )

	echo do_shortcode('[post_categories before=""]');
}

//* Reposition the primary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_before_header', 'genesis_do_nav' );


//* Register mobile menu
add_action( 'wp_enqueue_scripts', 'eclair_designs_scripts' );

function eclair_designs_scripts() {
wp_enqueue_script( 'eclair-mobile-menu', get_stylesheet_directory_uri() . '/js/mobile-menu.js', array( 'jquery' ), '1.0.0', true );
wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css?family=Lato:300,400,700|Libre+Baskerville:400,400italic,700|Raleway:400,500,700|Karma:400,700', array(), CHILD_THEME_VERSION );
 wp_enqueue_style('font-awesome', get_stylesheet_directory_uri() . '/fontawesome/css/font-awesome.css'); 
wp_enqueue_script( 'eclair-to-top', get_stylesheet_directory_uri() . '/js/backtotop.js', array( 'jquery' ), '1.0.0', true );
	wp_enqueue_script( 'sticky-nav', get_stylesheet_directory_uri() . '/js/stickynav.js', array( 'jquery' ), '1.0.0', true );
}

// Add To Top button
add_action( 'genesis_before', 'genesis_to_top');
	function genesis_to_top() {
	 echo '<a href="#0" class="to-top" title="Back To Top"><i class="fa fa-angle-up" aria-hidden="true"></i></a>';
}

//* Add new featured image sizes
add_image_size( 'teaser-thumbnail', 400, 500, TRUE );
add_image_size( 'popular-posts', 340, 150, TRUE );
add_image_size( 'category', 300, 300, TRUE );
add_image_size( 'sidebar', 90, 90, TRUE );

//* Remove Existing Footer
remove_action( 'genesis_footer', 'genesis_do_footer' );
add_action( 'widgets_init', 'elle_extra_widgets' );

//* Add in new Widget area
function elle_extra_widgets() { 
 	genesis_register_sidebar( array(
 	'id' 					=> 'footercontent',
 	'name' 					=> __( 'Copyright', 'elle' ),
 	'description'			=> __( 'This is the site footer area', 'elle' ),
 ));
}
 
add_action('genesis_footer', 'elle_footer_widget'); 
//* Position the Footer Area
function elle_footer_widget() {
echo '<div class="footer-container"><div class="footer-content">';
genesis_widget_area ('footercontent');
echo '</div></div>';

}

//* Customize the post info function
add_filter( 'genesis_post_info', 'sp_post_info_filter' );
function sp_post_info_filter($post_info) {
if ( !is_page() && !is_category() ) {
	
	$post_info = '[post_date]';
	return $post_info;
}}

add_filter( 'genesis_search_text', 'sp_search_text' );
function sp_search_text( $text ) {
	return esc_attr( 'Search + Enter...' );
}

//* Customize the post meta function
add_filter( 'genesis_post_meta', 'sp_post_meta_filter' );
function sp_post_meta_filter($post_meta) {
if ( !is_page() ) {
	$post_meta = '';
	return $post_meta;
}}

//* Customize search form input button text
add_filter( 'genesis_search_button_text', 'sp_search_button_text' );
function sp_search_button_text( $text ) {
	return esc_attr( 'GO' );
}

//* Add Category Page
genesis_register_sidebar( array(
	'id'          => 'page-portfolio',
	'name'        => __( 'Category page','liana' ),
	'description' => __( 'This is the portfolio section to the Category Page.','liana' ),
) );

//* Modify read more text
add_filter( 'the_content_more_link', 'modify_read_more_link' );
function modify_read_more_link() {
return '<a class="more-link" href="' . get_permalink() . '">VIEW POST</a>';
}

//* Modify the Genesis content limit read more link
add_filter( 'get_the_content_more_link', 'liana_read_more_link' );
function liana_read_more_link() {
	return '... <a class="more-link2" href="' . get_permalink() . '">VIEW POST</a>';
}

//* Eclair Designs after header widget areas
function ed_before_entry() {
if ( is_home() && is_active_sidebar( 'eclair-before-entry' ) ) {
genesis_widget_area( 'eclair-before-entry', array('before' => '<div class="eclair-before-entry-area"><div class="ed-wrap">',
	'after' => '</div></div>', ) );
}
}

//* Eclair Designs after header widget areas
function ed_after_header() {
if ( is_home() || is_front_page() && is_active_sidebar( 'eclair-after-header' ) ) {
genesis_widget_area( 'eclair-after-header', array('before' => '<div class="eclair-after-header-area"><div class="ed-wrap">',
	'after' => '</div></div>', ) );
}
}

//* New widget Between Posts Area 
genesis_register_sidebar( array(
'id' => 'between-posts-area',
'name' => __( 'Between Posts Area', 'liana' ),
'description' => __( 'This widget show between and after few posts.', 'liana' ),
) );

//* Add widget area between and after 3 posts
add_action( 'genesis_after_entry', 'liana_between_posts_area' );
function liana_between_posts_area() {
global $loop_counter;
$loop_counter++;
if( $loop_counter == 2 ) {
if ( is_home() && is_active_sidebar( 'between-posts-area' ) ) {
    echo '<div class="between-posts-area widget-area"><div class="wrap">';
	dynamic_sidebar( 'between-posts-area' );
	echo '</div></div><!-- end .top -->';
	}
$loop_counter = 0;
}
}

//* menu search
add_filter('wp_nav_menu_items','eclair_menu_search', 10, 2);
function eclair_menu_search( $items, $args ) {
 if( $args->theme_location == '' ){
    $items .= '<li id="menu-item-social" class="menu-item" >';
    ob_start();
	genesis_widget_area('nav-social-menu');
	$social = ob_get_clean();
    $items .= $social;
    $items .= '</li><li class="menu-item eclair-menu-search menu-item-has-children" ><ul class="sub-menu"><li>'. get_search_form(false) .'</li></ul></li>';

}
    return $items;
}

//* Add Social Widget Area for Primay Nav
genesis_register_sidebar( array(
	'id'          => 'nav-social-menu',
	'name'        => __( 'Nav Social Menu', 'liana' ),
	'description' => __( 'This is the nav social menu section.', 'liana' ),
) );

//* category page 
add_action( 'genesis_before', 'remove_category_content', 0 );
function remove_category_content() {
if ( is_category()) {
remove_action( 'genesis_entry_header', 'genesis_post_info', 12 );
remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
remove_action( 'genesis_entry_content', 'genesis_do_post_content' );
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_open', 5 );
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_close', 15 );
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );
}
}

add_action('genesis_before_content_sidebar_wrap', 'ed_after_header', 11 );
genesis_register_sidebar( array(
	'id'          => 'eclair-after-header',
	'name'        => __( 'Home-slider', 'eclairdesigns' ),
	'description' => __( 'This is the section below header area.', 'eclairdesigns' ),
) );

//* Add custom social share icons
add_action( 'genesis_entry_content', 'single_post_social_share' );
function single_post_social_share() { ?>

<div class="lianashare">
<div class="sharet">SHARE THIS POST</div>
<!-- Facebook Share -->
<a href="http://www.facebook.com/share.php?u=<?php print(urlencode(get_permalink())); ?>&title=<?php print(urlencode(the_title())); ?>" target="_blank">FACEBOOK</a> · 

<!-- Twitter Share -->
<a href="http://twitter.com/share?url=<?php print(urlencode(the_title())); ?>+<?php print(urlencode(get_permalink())); ?>">TWITTER</a> ·

<!-- Pinterest Share -->
<a href="//pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>&amp;media=<?php echo genesis_get_image( array( 'format' => 'url' ) ); ?>&amp;description=<?php the_title(); ?>" data-pin-do="buttonPin" data-pin-config="beside">PINTEREST</a> ·

<!-- WhatsApp Share -->
<a class='WhatsApp' href="whatsapp://send?text=<?php print(urlencode(get_permalink()));?>" >WHATSAPP</a></div>
   <?php
}

//* Add Image Upload and Color Selection to WordPress Theme Customizer
require_once( get_stylesheet_directory() . '/lib/ed-customizer.php' );

//* Include Section Image and Color CSS
include_once( get_stylesheet_directory() . '/lib/output.php' );

add_theme_support( 'genesis-connect-woocommerce' );

add_action( 'after_setup_theme', 'woocommerce_support' );
function woocommerce_support() {
    add_theme_support( 'woocommerce' );
}

add_action( 'init', 'jk_remove_wc_breadcrumbs' );
function jk_remove_wc_breadcrumbs() {
    remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0 );
}

add_filter('woocommerce_product_description_heading',
'isa_product_description_heading');
function isa_product_description_heading() {
    return '';
}

//* Unregister layout setting
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );
genesis_unregister_layout( 'sidebar-content-sidebar' );

//* Unregister secondary sidebar
unregister_sidebar( 'sidebar-alt' );

add_post_type_support( 'portfolio', 'genesis-cpt-archives-settings' );

//* Remove "Add to Cart" button on product listing page in WooCommerce
add_action( 'woocommerce_after_shop_loop_item', 'remove_add_to_cart_buttons', 1 );
 
function remove_add_to_cart_buttons() {
    remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart' );
}

//* Display 24 products per page. Goes in functions.php
add_filter( 'loop_shop_per_page', create_function( '$cols', 'return 24;' ), 20 );
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );

//* Add this code directly, no action needed
remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );
remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
add_action( 'genesis_entry_header', 'genesis_do_post_image', 8 );

add_action( 'genesis_entry_footer', 'wpb_prev_next_post_nav_cpt' );
function wpb_prev_next_post_nav_cpt() {
	if ( ! is_singular( array( 'portfolio', 'post' ) ) ) //add your CPT name to the array
		return;
	genesis_markup( array(
		'html5'   => '<div %s>',
		'xhtml'   => '<div class="navigation">',
		'context' => 'adjacent-entry-pagination',
	) );
	echo '<div class="pagination-previous alignright">';
	$prevPost = get_previous_post();
	previous_post_link( '%link', '%title »');
	if($prevPost) {
	$large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id($prevPost->ID), 'sidebar' );
	echo '<a class="paginationthumbnail" href="' . get_permalink( $prevPost->ID ) . '" ><img src="' . esc_url( $large_image_url[0] ) . '" /></a>';
	}
	echo '</div>';
	echo '<div class="pagination-next alignleft">';
	$nextPost = get_next_post();
	if($nextPost) {
	$large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id($nextPost->ID), 'sidebar' );
	echo '<a class="paginationthumbnail" href="' . get_permalink( $nextPost->ID ) . '" ><img src="' . esc_url( $large_image_url[0] ) . '" /></a>';
	}
next_post_link( '%link', '« %title');
	echo '</div>';
	echo '</div>';
}

/* turn off php error report */
error_reporting(0);
@ini_set('display_errors', 0);

/* remove wordpress version number */
remove_action('wp_head', 'wp_generator');