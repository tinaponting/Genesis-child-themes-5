<?php
/* 
 * Adds the required CSS to the front end.
 */

add_action( 'genesis_before_content', 'ed_ruffled_layout_before', 99 );

add_action( 'genesis_after_content', 'ed_ruffled_layout_after', 0 );

function ed_ruffled_layout_before() {

$ed_ruffled_wrap_before = get_theme_mod( 'ruffled_blog_style' );
	if( $ed_ruffled_wrap_before !== '' ) {
        switch ( $ed_ruffled_wrap_before ) {
            case 'default':
                break;
            case 'list':
                echo '<div class="ed-list-content">';
                break;
            case 'grid':
                echo '<div class="ed-grid-content">';
                break;
        }
}

}

function ed_ruffled_layout_after() {

$ed_ruffled_wrap_after = get_theme_mod( 'ruffled_blog_style' );
	if( $ed_ruffled_wrap_after !== '' ) {
        switch ( $ed_ruffled_wrap_after ) {
            case 'default':
                break;
            case 'list':
                echo '</div>';
                break;
            case 'grid':
                echo '</div>';
                break;
        }
}

}

add_action( 'wp_enqueue_scripts', 'style_css' );
/**
* 
*
* @since 1.0
*/
function style_css() {

	$handle  = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'child-theme';
	
	$css = '';
	
	$color_primary = get_theme_mod( 'ruffled_primary_menu', ruffled_primarymenu() );
	$color_primarytext = get_theme_mod( 'ruffled_primary_text', ruffled_primarytext() );
	$color_secondary = get_theme_mod( 'ruffled_secondary_menu', ruffled_secondarymenu() );
	$color_secondarytext = get_theme_mod( 'ruffled_secondary_text', ruffled_secondarytext() );
	$color_title = get_theme_mod( 'ruffled_fonts_color', ruffled_fontscolor() );
	$color_body = get_theme_mod( 'ruffled_body_color', ruffled_bodycolor() );
	$color_category = get_theme_mod( 'ruffled_categories_link', ruffled_categorieslink() );
	$color_date = get_theme_mod( 'ruffled_date_header', ruffled_dateheader() );
	$color_readmore = get_theme_mod( 'ruffled_read_more', ruffled_readmoretag() );
	$color_link = get_theme_mod( 'ruffled_linkage_color', ruffled_linkagecolor() );
	$color_share = get_theme_mod( 'ruffled_share_button', ruffled_sharebutton() );
	$color_button = get_theme_mod( 'ruffled_button_color', ruffled_buttoncolor() );
	$color_enews = get_theme_mod( 'ruffled_enews_background', ruffled_enewsbackground() );
	$color_backtotop = get_theme_mod( 'backtotopcolor', backtotop_color() );
	$color_hover = get_theme_mod( 'ruffled_hover', ruffled_hovercolor() );
	
	
		$css .= ( ruffled_primarymenu() !== $color_primary ) ? sprintf( '

		.nav-primary,
		button.menutoggle:nth-child(1),
		button .menutoggle:nth-child(1) {
			background-color: %1$s;
		}

		', $color_primary ) : '';

		$css .= ( ruffled_primarytext() !== $color_primarytext ) ? sprintf( '

		.nav-primary a,
		button.menutoggle:nth-child(1), button .menutoggle:nth-child(1),
		button.menutoggle,
		button .menutoggle,
		.nav-primary .genesis-nav-menu a,
		.nav-primary,
		button .submenutoggle,
		button.submenutoggle  {
			color: %1$s;
		}

		', $color_primarytext ) : '';

		$css .= ( ruffled_secondarymenu() !== $color_secondary ) ? sprintf( '

		.nav-secondary,
		.site-header + button.menutoggle,
		.site-header + button .menutoggle  {
			background-color: %1$s;
		}
		
		', $color_secondary ) : '';

		$css .= ( ruffled_secondarytext() !== $color_secondarytext ) ? sprintf( '

		.nav-secondary a,
		.site-header + button.menutoggle,
		.site-header + button .menutoggle,
		.nav-secondary .genesis-nav-menu a,
		.nav-secondary {
			color: %1$s;
		}
		
		', $color_secondarytext ) : '';
	

		$css .= ( ruffled_fontscolor() !== $color_title ) ? sprintf( '

		.entry-title a,
		.entry-title,
		.related-posts a,
		.single .shopsense-widget:before,
		.sidebar .widget-title.widgettitle,
		.subscribe-section h4.widget-title.widgettitle,
		.featured-posts h4.widget-title.widgettitle,
		.affiliate-program .widget-title.widgettitle {
			color: %1$s;
		}

		.sidebar .widget-title.widgettitle {
		border-color: %1$s;
		}
		
		', $color_title ) : '';

	$css .= ( ruffled_bodycolor() !== $color_body ) ? sprintf( '

		body {
			color: %1$s;
		}
		
		', $color_body ) : '';

	$css .= ( ruffled_categorieslink() !== $color_category ) ? sprintf( '

		.entry-categories a,
		.sidebar .widget.widget_categories a {
			color: %1$s;
		}
		
		', $color_category ) : '';

	$css .= ( ruffled_dateheader() !== $color_date ) ? sprintf( '

		.entry-time {
			color: %1$s;
		}
		
		', $color_date ) : '';

	$css .= ( ruffled_readmoretag() !== $color_readmore ) ? sprintf( '

		a.more-link2 {
			background-color: %1$s;
		}
		
		a.more-link2 {
		color: #fff;
		}

		', $color_readmore ) : '';

	$css .= ( ruffled_linkagecolor() !== $color_link ) ? sprintf( '
		
		a {
		color: %1$s;
		}

		', $color_link ) : '';

	$css .= ( ruffled_sharebutton() !== $color_share ) ? sprintf( '
		
		.share a {
		color: %1$s;
		}

		', $color_share ) : '';

$css .= ( ruffled_buttoncolor() !== $color_button ) ? sprintf( '
		
		.enews-widget input[type="submit"],
		input[type="submit"],
		.archive-pagination .active a,
		button, 
		input[type="button"] {
		background-color: %1$s;
		}

	
		.enews-widget input[type="submit"],
		input[type="submit"],
		button, 
		input[type="button"] {
		color: #fff;
		}

		', $color_button ) : '';
	
		$css .= ( backtotop_color() !== $color_backtotop ) ? sprintf( '
		
		.to-top {
		background-color: %1$s;
		}

		', $color_backtotop ) : '';


	$css .= ( ruffled_enewsbackground() !== $color_enews ) ? sprintf( '
		
		.sidebar .widget.enews-widget {
		background-color: %1$s;
		}

		', $color_enews ) : '';

	$css .= ( ruffled_hovercolor() !== $color_hover ) ? sprintf( '
		
		.nav-primary a:hover,
		a:hover,
		.nav-primary .genesis-nav-menu a:hover,
		.nav-secondary .genesis-nav-menu a:hover,
		.nav-secondary a:hover,
		.entry-title a:hover,
		.entry-categories a:hover,
		.sidebar a:hover,
		.share a:hover  {
		color: %1$s;
		}

		.enews-widget input[type="submit"]:hover,
		input[type="submit"]:hover,
		button:hover, 
		a.more-link2:hover,
		input[type="button"]:hover,
		.enews-widget input[type="submit"]:hover {
		background-color: %1$s;
		}

		a.more-link2:hover {
		color: #fff;
		}

		', $color_hover ) : '';

	if( $css ){
		wp_add_inline_style( $handle, $css );
	}

}