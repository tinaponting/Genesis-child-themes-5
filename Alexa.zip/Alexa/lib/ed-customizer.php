<?php

/**
 * @author Eclair Designs
 * @package Alexa
 * @subpackage Customizations
 */
 
function alexa_primarymenu()  {
	return '#f9f6f6';
}

function alexa_primarytext()  {
	return '#000';
}

function alexa_secondarymenu() {
	return '#fff';
}

function alexa_secondarytext() {
	return '#000';
}

function alexa_entrytitle() {
	return '#000';
}

function alexa_body() {
	return '#000';
}

function alexa_categorieslink() {
	return '#b98a68';
}

function alexa_dateheader() {
	return '#000';
}

function alexa_readmoretag() {
	return '#000';
}

function alexa_linkagecolor() {
	return '#b98a68';
}

function alexa_sharebutton() {
	return '#b98a68';
}

function alexa_comment_link() {
	return '#f9f6f6';
}

function alexa_hovercolor() {
	return '#000';
}

function sidebar_widgettitle() {
	return '#f5f5f5';
}

function alexa_footerbg() {
	return '#000';
}

function back_to_top() {
	return '#000';
}


add_action( 'customize_register', 'alexa_customizer' );



function alexa_customizer(){

	global $wp_customize;
	
	$wp_customize->add_setting(
		'alexa_primary_menu',
		array(
			'default' => alexa_primarymenu(),
		)
	);
	
	$wp_customize->add_setting(
		'alexa_primary_text',
		array(
			'default' => alexa_primarymenu(),
		)
	);

	$wp_customize->add_setting(
		'alexa_secondary_menu',
		array(
			'default' => alexa_secondarymenu(),
		)
	);

	$wp_customize->add_setting(
		'alexa_secondary_text',
		array(
			'default' => alexa_secondarymenu(),
		)
	);
	
		$wp_customize->add_setting(
		'alexa_entry_title',
		array(
			'default' => alexa_entrytitle(),
		)
	);
	
		$wp_customize->add_setting(
		'alexabody',
		array(
			'default' => alexa_body(),
		)
	);
	
		$wp_customize->add_setting(
		'alexa_categories_link',
		array(
			'default' => alexa_categorieslink(),
		)
	);
	
		$wp_customize->add_setting(
		'alexa_date_header',
		array(
			'default' => alexa_dateheader(),
		)
	);
	
		$wp_customize->add_setting(
		'alexa_readmore_tag',
		array(
			'default' => alexa_readmoretag(),
		)
	);
	
		$wp_customize->add_setting(
		'alexa_linkage_color',
		array(
			'default' => alexa_linkagecolor(),
		)
	);
	
		$wp_customize->add_setting(
		'alexa_share_button',
		array(
			'default' => alexa_sharebutton(),
		)
	);
	
			$wp_customize->add_setting(
		'alexa_commentlink',
		array(
			'default' => alexa_comment_link(),
		)
	);

	
					$wp_customize->add_setting(
		'alexa_hover_color',
		array(
			'default' => alexa_hovercolor(),
		)
	);
	
						$wp_customize->add_setting(
		'sidebar_widget_title',
		array(
			'default' => sidebar_widgettitle(),
		)
	);
	
	$wp_customize->add_setting(
		'alexa_footer_bg',
		array(
			'default' => alexa_footerbg(),
		)
	);
	
		$wp_customize->add_setting(
		'backtotop',
		array(
			'default' => back_to_top(),
		)
	);
	
	$wp_customize->add_section(  'alexa_blogstyle',  array(
				'title'      		=> __( 'Blog Post Style', 'alexa' ),				
				'description'		=> __('Manage the layout of blog listing.', 'alexa'),
				'priority'		=> 3
			)
		);

	$wp_customize->add_setting( 'alexa_blog_style', array(
				'default'   		=> 'default',
				'capability'     => 'edit_theme_options',
				'transport' 		=> 'refresh',				
		)
	);


	$wp_customize->add_control(
			'ruffled_blog_style', array(
				'label'     		=> __('Blog Post Style', 'alexa'),
				'description'		=> 'Manage the layout of blog listing.',
				'section'   		=> 'alexa_blogstyle',
				'settings'  		=> 'alexa_blog_style',
				'type'      		=> 'select',
				'choices'   		=> array(
					'default'     		=> __( 'default', 'laura' ),
					'list'      		=> __( 'list', 'laura' ),
				)
			)
		);	
	
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'alexa_primary_menu',
			array(
			    'description' => __( 'Customize the default background color of the primary navigation bar.', 'alexa' ),
			    'label'       => __( 'Primary Navigation Bar Color', 'alexa' ),
			    'section'     => 'colors',
			    'settings'    => 'alexa_primary_menu',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'alexa_primary_text',
			array(
			    'description' => __( 'Customize the default text color of the primary navigation bar.', 'alexa' ),
			    'label'       => __( 'Primary Navigation Bar Text', 'alexa' ),
			    'section'     => 'colors',
			    'settings'    => 'alexa_primary_text',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'alexa_secondary_menu',
			array(
			    'description' => __( 'Customize the background color of the secondary navigation bar.', 'alexa' ),
			    'label'       => __( 'Secondary Navigation Bar', 'alexa' ),
			    'section'     => 'colors',
			    'settings'    => 'alexa_secondary_menu',
			)
		)
	);
	
		$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'alexa_secondary_text',
			array(
			    'description' => __( 'Customize the text color of the secondary navigation bar.', 'alexa' ),
			    'label'       => __( 'Secondary Navigation Bar Text', 'alexa' ),
			    'section'     => 'colors',
			    'settings'    => 'alexa_secondary_text',
			)
		)
	);

			$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'alexa_entry_title',
			array(
			    'description' => __( 'Customize the text color of the entry title.', 'alexa' ),
			    'label'       => __( 'Entry Title', 'alexa' ),
			    'section'     => 'colors',
			    'settings'    => 'alexa_entry_title',
			)
		)
	);
	
				$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'alexabody',
			array(
			    'description' => __( 'Customize the text color of the content.', 'alexa' ),
			    'label'       => __( 'Body Text', 'alexa' ),
			    'section'     => 'colors',
			    'settings'    => 'alexabody',
			)
		)
	);
	
					$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'alexa_categories_link',
			array(
			    'description' => __( 'Customize the category link color.', 'alexa' ),
			    'label'       => __( 'Categories Links', 'alexa' ),
			    'section'     => 'colors',
			    'settings'    => 'alexa_categories_link',
			)
		)
	);
	
	
					$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'alexa_date_header',
			array(
			    'description' => __( 'Customize the date header color.', 'alexa' ),
			    'label'       => __( 'Date Header', 'alexa' ),
			    'section'     => 'colors',
			    'settings'    => 'alexa_date_header',
			)
		)
	);
	
						$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'alexa_readmore_tag',
			array(
			    'description' => __( 'Customize the read more tag color.', 'alexa' ),
			    'label'       => __( 'Read More Tag', 'alexa' ),
			    'section'     => 'colors',
			    'settings'    => 'alexa_readmore_tag',
			)
		)
	);
	
							$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'alexa_linkage_color',
			array(
			    'description' => __( 'Customize the linkages text color.', 'alexa' ),
			    'label'       => __( 'Linkages', 'alexa' ),
			    'section'     => 'colors',
			    'settings'    => 'alexa_linkage_color',
			)
		)
	);
	
	
							$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'alexa_share_button',
			array(
			    'description' => __( 'Customize the share icons color.', 'alexa' ),
			    'label'       => __( 'Share Icons', 'alexa' ),
			    'section'     => 'colors',
			    'settings'    => 'alexa_share_button',
			)
		)
	);
	
		$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'alexa_commentlink',
			array(
			    'description' => __( 'Customize the comments link color.', 'alexa' ),
			    'label'       => __( 'Comments Links', 'alexa' ),
			    'section'     => 'colors',
			    'settings'    => 'alexa_commentlink',
			)
		)
	);
		
		$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'sidebar_widget_title',
			array(
			    'description' => __( 'Customize the widget title text color.', 'alexa' ),
			    'label'       => __( 'Widget Title', 'alexa' ),
			    'section'     => 'colors',
			    'settings'    => 'sidebar_widget_title',
			)
		)
	);
	
		$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'alexa_hover_color',
			array(
			    'description' => __( 'Customize the hover color.', 'alexa' ),
			    'label'       => __( 'Hover color', 'alexa' ),
			    'section'     => 'colors',
			    'settings'    => 'alexa_hover_color',
			)
		)
	);
	
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'alexa_footer_bg',
			array(
			    'description' => __( 'Customize the background color of the footer widget area.', 'alexa' ),
			    'label'       => __( 'Footer background color', 'alexa' ),
			    'section'     => 'colors',
			    'settings'    => 'alexa_footer_bg',
			)
		)
	);
	
		$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'backtotop',
			array(
			    'description' => __( 'Customize the color of the back to top button.', 'alexa' ),
			    'label'       => __( 'Back to top button', 'alexa' ),
			    'section'     => 'colors',
			    'settings'    => 'back_to_top',
			)
		)
	);

}
