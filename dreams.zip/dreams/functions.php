<?php
//* this will bring in the Genesis Parent files needed:
include_once( get_template_directory() . '/lib/init.php' );

//* Child theme
define( 'CHILD_THEME_NAME', 'Dreams Theme' );
define( 'CHILD_THEME_VERSION', '1.0' );
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );
add_theme_support( 'genesis-responsive-viewport' );
add_theme_support( 'genesis-menus', array( 'primary' => __( 'Primary Navigation Menu', 'genesis' ) ) );

// Adds image upload and color select to Customizer.
require_once('lib/customizer_setting.php');

// Includes Customizer CSS.
require_once('lib/customizer_output.php'); 

// SkyandStars widget.
require_once('lib/skystars_widget.php');

// Theme default settings.
include_once( get_stylesheet_directory() . '/lib/theme-defaults.php' );

// Adds required plugins for this theme.
require_once dirname( __FILE__ ) . '/lib/class-tgm-plugin-activation.php';
add_action( 'tgmpa_register', 'skyandstars_required_plugins' );
function skyandstars_required_plugins() {
 
    $plugins = array(
		array(
			'name'      => 'Social Slider Widget',
			'slug'      => 'instagram-slider-widget',
			'required'  => false,
		),
		array(
			'name'      => 'Genesis Simple Share',
			'slug'      => 'genesis-simple-share',
			'required'  => false,
		),
		array(
			'name'      => 'Genesis eNews Extended',
			'slug'      => 'genesis-enews-extended',
			'required'  => false,
		),
		array(
			'name'      => 'Regenerate Thumbnails',
			'slug'      => 'regenerate-thumbnails',
			'required'  => false,
		),
		array(
			'name'      => 'Contact Form 7',
			'slug'      => 'contact-form-7',
			'required'  => false,
		),
	);
	

    $config = array( /* The array to configure TGM Plugin Activation */ );
 
    tgmpa( $plugins, $config );
 
}
/* end muplugin*/


//Enqueues scripts and styles.
add_action( 'wp_enqueue_scripts', 'skyandstars_enqueue_scripts' );
function skyandstars_enqueue_scripts() {

	wp_enqueue_script( 'fitvids', get_stylesheet_directory_uri() . '/js/jquery.fitvids.js', array( 'jquery' ), '1.0.0', true );
	wp_enqueue_script( 'prefix-responsive-menu', get_stylesheet_directory_uri() . '/js/responsivemenu.js', array( 'jquery' ), '1.0.0', true );
	wp_enqueue_script( 'site-script', get_stylesheet_directory_uri() . '/js/script.js', array( 'jquery' ), '1.0.0', true );
	wp_enqueue_style( 'google-font', 'https://fonts.googleapis.com/css?family=Karla:400,400i,700,700i|Oswald:300,400|Work+Sans', array(), '1.0' );
	wp_enqueue_style( 'fontawesome', '//maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css' );
	wp_enqueue_style( 'dashicons' );
}


// Adds image sizes.
add_image_size('sidebar-featured', 300, 300, TRUE);
add_image_size('autoreadmore', 1024, 820, TRUE);
add_image_size('autoreadmore_por', 820, 1024, TRUE);
add_image_size('related-img', 500, 500, TRUE);
add_image_size('featured_post', 360, 240, TRUE);


//* Add support for custom header
add_theme_support( 'genesis-custom-header');
add_theme_support( 'custom-header', array(
	'header-selector' => '.site-title a',
	'header-text'     => false,
	'height'      => 300,
    'width'       => 800,
    'flex-height' => true,
    'flex-width'  => true,
) );

// Removes header right widget area.
unregister_sidebar( 'header-right' );

// Move Primary Nav Menu Above Header
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_before_header', 'genesis_do_nav' );

// Removes site layouts.
 genesis_unregister_layout( 'content-sidebar-sidebar' );
 genesis_unregister_layout( 'sidebar-sidebar-content' );
 genesis_unregister_layout( 'sidebar-content-sidebar' );

//* Enable the superfish script
add_filter( 'genesis_superfish_enabled', '__return_true' );

/*========================== HEADER WIDGETS ========================== */
//dibawah header
genesis_register_sidebar( array(
    'id'                => 'cta-1',
    'name'          => __( '3 Featured Items Header', 'rosemary' ),
    'description'   => __( 'Place 3 Images widget and Link under logo', 'rosemary' ),
) );
add_action( 'genesis_after_header', 'rosemary_cta_genesis' );

/**
 * Add CTA widget support for site. If widget not active, don't display
 *
 */
function rosemary_cta_genesis() {

  // Don't display the CTA on the home page, since it's built into the MP theme
  if ( is_home() ) {
        genesis_widget_area( 'cta-1', array(
            'before' => '<div id="home-featured"><div class="wrap">',
            'after' => '</div></div>',
        ) );
    }

}

/*========================== SOSMED samping menu ========================== */
genesis_register_sidebar( array(
	'id'          => 'nav-social-menu',
	'name'        => __( 'Social Media Top Menu', 'yooons-theme' ),
	'description' => __( 'This is the social media menu section.', 'yooons-theme' ),
) );

add_filter( 'genesis_nav_items', 'sws_social_icons', 10, 2 );
add_filter( 'wp_nav_menu_items', 'sws_social_icons', 10, 2 );

function sws_social_icons($menu, $args) {
	$args = (array)$args;
	if ( 'primary' !== $args['theme_location'] )
		return $menu;
	ob_start();
	genesis_widget_area('nav-social-menu');
	$social = ob_get_clean();
	return $menu . $social;
}

/*========================== POSTING AREA ========================== */
//admin bar wordpress
if(is_admin_bar_showing() && !is_admin()) {
    function link_to_stylesheet() {
        ?>
            <style type="text/css">#menu {top:31px;}</style>
        <?php
    }
    add_action('wp_head', 'link_to_stylesheet');
}

//* Customize the entry meta in the entry header
add_filter( 'genesis_post_info', 'ss_post_info_filter' );
function ss_post_info_filter($post_info) {
    $post_info = '[post_date] [post_comments zero="Leave a Comment" one="Comment : 1" more="Comments : %"] [post_edit]';
    return $post_info;
}

//* Gutenberg full width image
function mytheme_setup() {
  add_theme_support( 'align-wide' );
}
add_action( 'after_setup_theme', 'mytheme_setup' );

//* Add Post categories above Post title before title in home and archives
add_action ( 'genesis_entry_content', 'sk_show_category_name', 9 );
function sk_show_category_name() {
		echo do_shortcode('[post_categories before=""]');
		return;
}


//* Add Post categories above Post title on single Posts
add_action ( 'genesis_entry_header', 'ss_show_category_name', 9 );
function ss_show_category_name() {

		echo do_shortcode('[post_categories before=""]');
		remove_action( 'genesis_entry_content', 'sk_show_category_name', 9 );

		return;
}

// Auto Read More
add_filter('excerpt_more', 'auto_excerpt_more');
function auto_excerpt_more($more) {
    return '<a class="autoreadmore" href="'.get_permalink().'" rel="nofollow">Read <span>the</span> Post</a>';
}

//* Modify the Genesis content limit read more link
add_filter( 'get_the_content_more_link', 'sp_read_more_link' );
function sp_read_more_link() {
	return '<a class="autoreadmore" href="' . get_permalink() . '">Read <span>the</span> Post</a>';
}

/*========================== CUSTOM FIELDS ========================== */
add_action( 'genesis_entry_content', 'custom_field_after_content', 10 );
/**
* @author Brad Dalton - WP Sites
* @link http://wp.me/p1lTu0-9WF
*/
function custom_field_after_content() {

	if ( ! is_category() ) {
		echo '<div id="shopthelook" class="stl">'; 
		echo '<h4 class="stl_title">';
		echo genesis_custom_field('shopthelook_title');
		echo '</h4>';
		echo genesis_custom_field('shopthelook_code');
		echo '</div>';
	}
}


/*========================== PREV NEXT ========================== */
//* Remove the post meta function from footer
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

 
//* Customize the next page link in the entry navigation
add_filter ( 'genesis_next_link_text' , 'ss_next_page_link' );
function ss_next_page_link ( $text ) {
	return 'Next Page &raquo;';
}

//* Customize the previous page link in the entry navigation
add_filter ( 'genesis_prev_link_text' , 'ss_previous_page_link' );
function ss_previous_page_link ( $text ) {
 
	return '&laquo; Previous Page';
 
}
add_action( 'genesis_before_comments', 'prev_next_post_nav', 12 );
function prev_next_post_nav() {
    if ( is_single() ) {
        echo '<div class="prevnext-post">';
        previous_post_link( '%link', '<div class="previous"><strong>Previous:</strong><br /> %title</div>' );
        next_post_link( '%link', '<div class="next"><strong>Next:</strong><br /> %title</div>'); 
        echo '</div><!-- .prev-next-navigation -->';
    }
}

/*========================== RELATED POSTS ========================== */
add_action( 'genesis_before_comments', 'skyandstars_related_posts', 8 );
function skyandstars_related_posts() {

	global $do_not_duplicate;
	if ( ! is_singular ( 'post' ) ) {
		return;
	}

	$count = 0;
	$related = '';
	$do_not_duplicate = array();
	$cats = wp_get_post_categories( get_the_ID() );


	// If we have some categories and less than 5 posts, run the cat query.
	if ( $cats && $count <= 4 ) {
		$query    = sky_related_cat_query( $cats, $count );
		$related .= $query['related'];
		$count    = $query['count'];
	}

	// End here if we don't have any related posts.
	if ( ! $related ) {
		return;
	}

	// Display the related posts section.
	echo '<div class="related">';
		echo '<h3 class="widget-title">You might also enjoy</h3>';
		echo '<div class="related-posts-list" data-columns>' . $related . '</div>';
	echo '</div>';

}

function sky_related_cat_query( $cats, $count ) {

	global $do_not_duplicate;

	if ( ! $cats ) {
		return;
	}

	$postIDs = array_merge( array( get_the_ID() ), $do_not_duplicate );

	$catIDs = array();

	foreach ( $cats as $cat ) {
		if ( 3 == $cat ) {
			continue;
		}
		$catIDs[] = $cat;
	}

	$showposts = 3 - $count;

	$tax_query = array(
		array(
			'taxonomy'  => 'post_format',
			'field'     => 'slug',
			'terms'     => array(
				'post-format-link',
				'post-format-status',
				'post-format-aside',
				'post-format-quote'
				),
			'operator' => 'NOT IN'
		)
	);
	$args = array(
		'category__in'          => $catIDs,
		'post__not_in'          => $postIDs,
		'showposts'             => $showposts,
		'ignore_sticky_posts'   => 1,
		'orderby'               => 'rand',
		'tax_query'             => $tax_query,
	);

	$related  = '';

	$cat_query = new WP_Query( $args );

	if ( $cat_query->have_posts() ) {
		while ( $cat_query->have_posts() ) {
			$cat_query->the_post();

			$count++;

			// $title = genesis_truncate_phrase( get_the_title(), 35 );
			$title = get_the_title();

			$related .= '<div class="related-post">';
			$related .= '<a class="related-image" href="' . get_permalink() . '" rel="bookmark" title="Permanent Link to ' . $title . '">' . genesis_get_image( array( 'size' => 'related-img' ) ) . '</a>';
			$related .= '<a class="related-post-title" href="' . get_permalink() . '" rel="bookmark" title="Permanent Link to ' . $title . '">' . $title . '</a>';
			$related .= '</div>';

		}
	}

	wp_reset_postdata();

	$output = array(
		'related' => $related,
		'count'   => $count
	);

	return $output;

}

/*========================== FOOTER AREA ========================== */
//CREDITS
function genesischild_footer_creds_text () {
  echo '<div class="creds">Design by <a href="http://skyandstars.co/" target="_blank">SkyandStars.co</a></div>';
}
add_filter( 'genesis_pre_get_option_footer_text', 'genesischild_footer_creds_text', 9 ); 


//Instagram Widget
function genesischild_footerwidgetheader() {
	genesis_register_sidebar( array(
	'id' => 'footerwidgetheader',
	'name' => __( 'Instagram Widget', 'genesis' ),
	'description' => __( 'This is for full width instagram widget', 'genesis' ),
	) );
}
add_action ('widgets_init','genesischild_footerwidgetheader');
function genesischild_footerwidgetheader_position ()  {
	echo '<div class="instagramwidget"><div class="wrap">';
	genesis_widget_area ('footerwidgetheader');
	echo '</div></div>';

}
add_action ('genesis_before_footer','genesischild_footerwidgetheader_position');

/*========================== WIDGET ========================== */
//search
add_filter( 'genesis_search_button_text', 'ss_genesis_search_button_text' );
function ss_genesis_search_button_text( $text ) {
  return esc_attr( 'GO' );
}

/*========================== SOCIAL PAGE ========================== */
function yoon_socpage() {
	genesis_register_sidebar( array(
	'id' => 'socpage-widgets-1',
	'name' => __( 'Social Page', 'genesis' ),
	'description' => __( 'Displaying items for your Social Media landing page', 'genesis' ),
	) );
}
add_action ('widgets_init','yoon_socpage');

?>