<?php
/**
 * This file adds the portfolio page template to the Chloe Theme.
 * @author Eclair Designs
 * @subpackage Customizations
 */
/*
Template Name: Portfolio
*/
add_action( 'genesis_meta', 'chloe_portfolio_page' );
/**
 * Add widget support for homepage. If no widgets active, display the default loop.
 *
 */
function chloe_portfolio_page() {
	if ( is_active_sidebar( 'page-portfolio' ) ) {
		// Force content-sidebar layout setting
		add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
		// Add chloe-home body class
		add_filter( 'body_class', 'chloe_body_class' );
		// Remove the default Genesis loop
		remove_action( 'genesis_loop', 'genesis_do_loop' );
		// Add homepage widgets
		add_action( 'genesis_loop', 'chloe_portfolio_page_widget' );
	}
}
function chloe_body_class( $classes ) {
	$classes[] = 'chloe-home';
	return $classes;
	
}
function chloe_portfolio_page_widget() {
	genesis_widget_area( 'page-portfolio', array(
		'before' => '<div id="portfolio"><div class="wrap">',
		'after'  => '</div></div>',
	) );
}
genesis();