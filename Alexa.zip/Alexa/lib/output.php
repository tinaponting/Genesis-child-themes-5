<?php
/* 
 * Adds the required CSS to the front end.
 */

add_action( 'genesis_before_content_sidebar_wrap', 'alexa_layout_before', 99 );

add_action( 'genesis_after_content_sidebar_wrap', 'alexa_layout_after', 0 );

function alexa_layout_before() {

$ed_ruffled_wrap_before = get_theme_mod( 'alexa_blog_style' );
	if( $ed_ruffled_wrap_before !== '' ) {
        switch ( $ed_ruffled_wrap_before ) {
            case 'default':
                break;
            case 'list':
                echo '<div class="alexa-list"><div class="wrap">';
                break;
        }
}

}

function alexa_layout_after() {

$ed_ruffled_wrap_after = get_theme_mod( 'ruffled_blog_style' );
	if( $ed_ruffled_wrap_after !== '' ) {
        switch ( $ed_ruffled_wrap_after ) {
            case 'default':
                break;
            case 'list':
                echo '</div></div>';
                break;

        }
}

}

add_action( 'wp_enqueue_scripts', 'style_css' );
/**
* 
*
* @since 1.0
*/
function style_css() {

	$handle  = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'child-theme';
	
	$css = '';
	
	$color_primary = get_theme_mod( 'alexa_primary_menu', alexa_primarymenu() );
	$color_primarytext = get_theme_mod( 'alexa_primary_text', alexa_primarytext() );
	$color_secondary = get_theme_mod( 'alexa_secondary_menu', alexa_secondarymenu() );
	$color_secondarytext = get_theme_mod( 'alexa_secondary_text', alexa_secondarytext() );
	$color_entrytitle = get_theme_mod( 'alexa_entry_title', alexa_entrytitle() );
	$color_body = get_theme_mod( 'alexabody', alexa_body() );
	$color_categories = get_theme_mod( 'alexa_categories_link', alexa_categorieslink() );
	$color_date = get_theme_mod( 'alexa_date_header', alexa_dateheader() );
	$color_read = get_theme_mod( 'alexa_readmore_tag', alexa_readmoretag() );
	$color_link = get_theme_mod( 'alexa_linkage_color', alexa_linkagecolor() );
	$color_share = get_theme_mod( 'alexa_share_button', alexa_sharebutton() );
	$color_comments = get_theme_mod( 'alexa_commentlink', alexa_comment_link() );
	$color_hover = get_theme_mod( 'alexa_hover_color', alexa_hovercolor() );
	$color_widgettitle = get_theme_mod( 'sidebar_widget_title', sidebar_widgettitle() );
	$color_footerbg = get_theme_mod( 'alexa_footer_bg', alexa_footerbg() );
	$color_top = get_theme_mod( 'backtotop', back_to_top() );
	
	$css .= ( alexa_primarymenu() !== $color_primary ) ? sprintf( '
		
		.nav-primary {
			background-color: %1$s;
		}

		', $color_primary ) : '';

	$css .= ( alexa_primarytext() !== $color_primarytext) ? sprintf( '
		
		.nav-primary .genesis-nav-menu a {
			color: %1$s;
		}
		
		', $color_primarytext ) : '';

	
	$css .= ( alexa_secondarymenu() !== $color_secondary ) ? sprintf( '
		
		.nav-secondary{
			background-color: %1$s;
		}

		', $color_secondary ) : '';

	$css .= ( alexa_secondarytext() !== $color_secondarytext ) ? sprintf( '
		
		.nav-secondary a {
			color: %1$s;
		}
		
		', $color_secondarytext ) : '';
	
	$css .= ( alexa_entrytitle() !== $color_entrytitle ) ? sprintf( '
		
		.entry-title a, .slide-excerpt-border h2, .slide-excerpt-border h2 a, .entry-title {
			color: %1$s;
		}
		
		', $color_entrytitle ) : '';

		$css .= ( alexa_body() !== $color_body ) ? sprintf( '
		
		body {
			color: %1$s;
		}
		
		', $color_body ) : '';
	
		$css .= ( alexa_categorieslink() !== $color_categories ) ? sprintf( '
		
		.entry-categories a, .logged-in-as a {
			color: %1$s;
		}
		
		', $color_categories ) : '';
	
		$css .= ( alexa_categorieslink() !== $color_categories ) ? sprintf( '
		
		.entry-categories a, .logged-in-as a {
			color: %1$s;
		}
		
		', $color_categories ) : '';
		
		$css .= ( alexa_dateheader() !== $color_date ) ? sprintf( '
		
		.entry-header .entry-meta {
			color: %1$s;
		}
		
		', $color_date ) : '';
	
	   $css .= ( alexa_readmoretag() !== $color_read ) ? sprintf( '
		
		.slide-excerpt-border a.more-link {
			border-color: %1$s;
		}
		
		.slide-excerpt-border a.more-link {
		color: %1$s;
		}
		
		.content a.more-link {
		outline-color: %1$s;
		}
		
		.content a.more-link  {
			background: %1$s;
		}
		
		.content a.more-link  {
			color: #fff;
		}
		
		
		', $color_read ) : '';
	
		$css .= ( alexa_linkagecolor() !== $color_link ) ? sprintf( '
		
		a {
			color: %1$s;
		}
		
		', $color_link ) : '';
	
		$css .= ( alexa_sharebutton() !== $color_share ) ? sprintf( '
		
		.lianashare a {
			color: %1$s;
		}
		
		', $color_share ) : '';
	$css .= ( alexa_comment_link() !== $color_comments ) ? sprintf( '
		
		.entry-comments-link a {
			color: %1$s;
		}
		
		', $color_comments ) : '';
			 
		$css .= ( alexa_hovercolor() !== $color_hover ) ? sprintf( '
		
		.entry-comments-link a:hover, a:hover, .entry-categories a:hover, .nav-primary .genesis-nav-menu a:hover, .nav-secondary a:hover, .slide-excerpt-border a.more-link:hover  {
			color: %1$s;
		}
		
		.slide-excerpt-border a.more-link:hover {
			border-color: %1$s;
		}
		
		.content a.more-link:hover  {
		outline-color: %1$s;
		}
		
		.content a.more-link:hover, .home.blog .archive-pagination.pagination a:hover  {
			background: %1$s;
		}

		
		', $color_hover ) : '';

		$css .= ( sidebar_widgettitle() !== $color_widgettitle ) ? sprintf( '
		
		.sidebar .widget-title {
			color: %1$s;
		}
		
		', $color_widgettitle ) : '';
				 
		$css .= ( alexa_footerbg() !== $color_footerbg ) ? sprintf( '
		
		.alexa-bestposts, .alexa-trending {
			background-color: %1$s;
		}
		
		.alexa-bestposts, .alexa-trending {
			outline-color: %1$s;
		}
		
		', $color_footerbg ) : '';
			 
	$css .= ( back_to_top() !== $color_top ) ? sprintf( '
		
		.to-top i.fa.fa-angle-up {
			color: %1$s;
		}
		
		', $color_top ) : '';
	
	if( $css ){
		wp_add_inline_style( $handle, $css );
	}

}