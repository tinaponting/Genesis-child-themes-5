<?php
/* replace old color */
function skyandstars_customizer_head_styles() {
?>
<style type="text/css">

<?php

	// HEADER LOGO HEIGHT
	$header_logo_height = get_theme_mod( 'header_logo_height' ); 
	if ( $header_logo_height != '180' ) :
	?>
		
			body{
				min-height: <?php echo $header_logo_height; ?>px;
			}
		
	<?php
	endif;

	// Background Color
	$bgx_color = get_theme_mod( 'bgx_color' ); 
	if ( $bgx_color != '#fbf4f4' ) :
	?>
		
			body {
				background-color: <?php echo $bgx_color; ?>;
			}
		
	<?php
	endif;

	// TEXT COLOR
	$text_color = get_theme_mod( 'text_color' ); 
	if ( $text_color != '#333333' ) :
	?>
		
			body,
			.about-widget,
			.sidebar #socmedicons a {
				color: <?php echo $text_color; ?>;
			}
		
	<?php
	endif;
	
	// POST TITLE COLOR
	$posttitle_color = get_theme_mod( 'posttitle_color' ); 
	if ( $posttitle_color != '#333333' ) :
	?>
			.entry-title a,
			.sidebar .widget-title a  {
				color: <?php echo $posttitle_color; ?>!important;
			}

	<?php
	endif;
	
	// LINK COLOR
	$content_link_color = get_theme_mod( 'content_link_color' ); 
	if ( $content_link_color != '#e1bbb7' ) :
	?>
		
			.entry-content p a {
				color: <?php echo $content_link_color; ?>;
			}
		
	<?php
	endif;

	// HOVER COLOR
	$link_hvrcolor = get_theme_mod( 'link_hvrcolor' ); 
	if ( $link_hvrcolor != '#edb0b0' ) :
	?>
			.entry-title a:focus,
			.entry-title a:hover,
			a:hover,
			.sidebar .widget a:hover,
			.sidebar #socmedicons a:hover,
			.tagcloud a:hover,
			.prevnext-post a:hover,
			.related-post a:hover,
			.sidebar .featured-content  .entry-content a.more-link:hover,
			.site-footer a:hover {
				color: <?php echo $link_hvrcolor; ?>;
			}
			.archive-pagination li a:hover {
				background-color: <?php echo $link_hvrcolor; ?>;
			}
			.entry-content p a:hover {
				color: <?php echo $link_hvrcolor; ?>;
				border-bottom: 1px solid <?php echo $link_hvrcolor; ?>;
			}
			.entry-categories::after {
				border-bottom: 1px solid <?php echo $link_hvrcolor; ?>;
			}

		
	<?php
	endif;
	
	// MENU BACKGROUND
	$menu_bg_color = get_theme_mod( 'menu_bg_color' ); 
	if ( $menu_bg_color != '#ffffff' ) :
	?>
		
			#menu, 
			.genesis-nav-menu .sub-menu a,
			.genesis-nav-menu .sub-menu a:hover,
			button.menu-toggle, button.sub-menu-toggle,
			.search-div {
				background-color: <?php echo $menu_bg_color; ?>;
			}
		
	<?php
	endif;
	
	// MENU LINK
	$menu_link_color = get_theme_mod( 'menu_link_color' ); 
	if ( $menu_link_color != '#333333' ) :
	?>
			.nav-primary .genesis-nav-menu a, 
			.nav-primary .genesis-nav-menu .sub-menu a, 
			.nav-primary .genesis-nav-menu .current-menu-item > a, 
			#socmedicons a {
				color: <?php echo $menu_link_color; ?>;
			}
			button.menu-toggle, 
			button.sub-menu-toggle {
				color: <?php echo $menu_link_color; ?>;
			}
		
	<?php
	endif;
	
	// MENU LINK HOVER
	$menu_link_hvrcolor = get_theme_mod( 'menu_link_hvrcolor' ); 
	if ( $menu_link_color != '#656460' ) :
	?>
		
			.nav-primary .genesis-nav-menu a:hover, 
			.genesis-nav-menu .sub-menu a:hover, 
			.nav-primary .genesis-nav-menu .sub-menu .current-menu-item > a:hover,
			.nav-primary .genesis-nav-menu .sub-menu li a:hover,
			#socmedicons a:hover {
				color: <?php echo $menu_link_hvrcolor; ?>!important;
			}
		
	<?php
	endif;
	
	// BUTTON COLOR
	$btn_color = get_theme_mod( 'btn_color' ); 
	if ( $btn_color != '#000000' ) :
	?>
		
			.entry-content p a.autoreadmore,
			.enews-widget input[type="submit"] {
				background-color: <?php echo $btn_color; ?>;
			}
			.comment-respond input[type="submit"] {
				background-color: <?php echo $btn_color; ?>;
			}
			.site-inner button, 
			input[type="button"], 
			input[type="reset"], 
			input[type="submit"], 
			.button,
			.search-form input[type="submit"] {
				background-color: <?php echo $btn_color; ?>;
			}
		
	<?php
	endif;
	
	// BUTTON TEXT COLOR
	$btn_txt_color = get_theme_mod( 'btn_txt_color' ); 
	if ( $btn_txt_color != '#ffffff' ) :
	?>
			.entry-content p a.autoreadmore {
				color: <?php echo $btn_txt_color; ?>!important;
			}

			.enews-widget input[type="submit"] {
				color: <?php echo $btn_txt_color; ?>!important;
			}
			.comment-respond input[type="submit"] {
				color: <?php echo $btn_txt_color; ?>!important;
			}
			.site-inner button, 
			input[type="button"], 
			input[type="reset"], 
			input[type="submit"], 
			.button,
			.search-form input[type="submit"] {
			    color: <?php echo $btn_txt_color; ?>!important;
			}
			.page .entry-content button, 
			.page .entry-content input[type="button"], 
			.page .entry-content input[type="reset"], 
			.page .entry-content input[type="submit"], 
			.page .entry-content .button {
				color: <?php echo $btn_txt_color; ?>!important;
			}
			
	<?php
	endif;
	
	// BUTTON HOVER COLOR
	$btn_hvrcolor = get_theme_mod( 'btn_hvrcolor' ); 
	if ( $btn_hvrcolor != '#edb0b0' ) :
	?>

			.entry-content p a.autoreadmore:hover,
			.enews-widget input[type="submit"]:hover {
				background-color: <?php echo $btn_hvrcolor; ?>;
			}
			.comment-respond input[type="submit"]:hover {
				background-color: <?php echo $btn_hvrcolor; ?>;
			}
			.site-inner button:hover, 
			input[type="button"]:hover, 
			input[type="reset"]:hover, 
			input[type="submit"]:hover, 
			.button:hover,
			.search-form input[type="submit"]:hover {
			    background-color: <?php echo $btn_hvrcolor; ?>;
			}
		
	<?php
	endif;
	
	
	
	// BUTTON TEXT HOVER COLOR
	$btntxt_hvrcolor = get_theme_mod( 'btntxt_hvrcolor' ); 
	if ( $btntxt_hvrcolor != '#ffffff' ) :
	?>

			.entry-content p a.autoreadmore:hover,
			.enews-widget input[type="submit"]:hover {
				color: <?php echo $btntxt_hvrcolor; ?>!important;
			}
			.comment-respond input[type="submit"]:hover {
				color: <?php echo $btntxt_hvrcolor; ?>!important;
			}
			.site-inner button:hover, 
			input[type="button"]:hover, 
			input[type="reset"]:hover, 
			input[type="submit"]:hover, 
			.button:hover,
			.search-form input[type="submit"]:hover {
			    color: <?php echo $btntxt_hvrcolor; ?>!important;
			}
			
			.page .entry-content button:hover, .page .entry-content input[type="button"]:hover, .page .entry-content input[type="reset"]:hover, .page .entry-content input[type="submit"]:hover, .page .entry-content .button:hover {
				color: <?php echo $btntxt_hvrcolor; ?>!important;
			}
	<?php
	endif;

	// WIDGET TEXT COLOR
	$widgettxt_color = get_theme_mod( 'widgettxt_color' ); 
	if ( $widgettxt_color != '#5f5f5f' ) :
	?>
		
			aside .widget-title, 
			.footer-widgets .widget-title {
				color: <?php echo $widgettxt_color; ?>;
			}
		
	<?php
	endif;
	

	// CATEGORY TEXT COLOR
	$catlink_color = get_theme_mod( 'catlink_color' ); 
	if ( $catlink_color != '#5d5d5d' ) :
	?>
		
			.widget_categories li a {
				color: <?php echo $catlink_color; ?>!important;
			}
		
	<?php
	endif;

	// CATEGORY TEXT HOVER COLOR
	$catlinkhvr_color = get_theme_mod( 'catlinkhvr_color' ); 
	if ( $catlinkhvr_color != '#ffffff' ) :
	?>
		
			.sidebar .widget_categories li a:hover  {
				color: <?php echo $catlinkhvr_color; ?>!important;
			}
		
	<?php
	endif;
	
	// CATEGORY BG COLOR
	$catbg_color = get_theme_mod( 'catbg_color' ); 
	if ( $catbg_color != '#ffffff' ) :
	?>
			.sidebar .widget_categories li a {
				background-color: <?php echo $catbg_color; ?>!important;
			}
			
	<?php
	endif;

	// CATEGORY BG HOVER COLOR
	$catbghvr_color = get_theme_mod( 'catbghvr_color' ); 
	if ( $catbghvr_color != '#edb0b0' ) :
	?>
			.widget_categories li a:hover {
				background-color: <?php echo $catbghvr_color; ?>!important;
			}
			
	<?php
	endif;
	
	// Mailchimp subs box
	$mchimp_box = get_theme_mod( 'mchimp_box' ); 
	if ( $mchimp_box != '#f2e7e7' ) :
	?>
			.sidebar .enews {
				background-color: <?php echo $mchimp_box; ?>!important;
			}
			
	<?php
	endif;

	?>
</style>
<?php
}
add_action( 'wp_head', 'skyandstars_customizer_head_styles' );
?>