<?php
/**
 * This file adds the front page to the Fairlight Child Theme.
 *
 */

add_action( 'genesis_meta', 'ds_home_genesis_meta' );
/**
 * Add widget support for homepage. If no widgets active, display the default loop.
 *
 */
function ds_home_genesis_meta() {

	if ( is_active_sidebar( 'home-top' ) || is_active_sidebar( 'home-middle' ) || is_active_sidebar( 'home-bottom' ) ) {

		// Force content-sidebar layout setting
		add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );

		// Add ds-home body class
		add_filter( 'body_class', 'ds_body_class' );
		function ds_body_class( $classes ) {
   			$classes[] = 'ds-home';
  			return $classes;
		}

		// Remove the default Genesis loop
		remove_action( 'genesis_loop', 'genesis_do_loop' );

		// Add homepage widgets
		add_action( 'genesis_loop', 'ds_homepage_widgets' );
		
		// Remove footer widgets
		remove_action( 'genesis_before_footer', 'genesis_footer_widget_areas' );

	}
}


function ds_homepage_widgets() {
	
	if ( is_active_sidebar( 'home-top' ) ) {

		echo '<div class="home-top">';

		genesis_widget_area( 'home-top', array(
			'before' => '<div class="home-top widget-area">',
			'after'  => '</div>',
		) );

	
	}

	
	if ( is_active_sidebar( 'home-middle' ) ) {

		echo '<div class="home-middle">';

		genesis_widget_area( 'home-middle', array(
			'before' => '<div class="home-middle widget-area">',
			'after'  => '</div>',
		) );

		echo '</div>';
	
	}
	
		if ( is_active_sidebar( 'home-bottom' ) ) {

		echo '<div class="home-bottom">';

		genesis_widget_area( 'home-bottom', array(
			'before' => '<div class="home-bottom widget-area">',
			'after'  => '</div>',
		) );

		echo '</div>';
	
	}

}

genesis();