<?php
/**
 * This file adds the Home Page to the Mrs Chalkboard Theme.
 * @package Mrs Chalkboard
 * @subpackage Customizations
 */

add_action( 'genesis_meta', 'mrs_widget_before_content' );

//* Add Homepage Slider Widget
function mrs_widget_before_content() {

if ( is_home() && is_active_sidebar('before-content') ) {

	add_action( 'genesis_before_loop', 'mrs_home_sections' );
	add_filter( 'body_class', 'mrs_add_home_body_class' );

//* Add body class to home page
function mrs_add_home_body_class( $classes ) {

	$classes[] = 'mrs-home';
	return $classes;

	}
	
    }
}

function mrs_home_sections() {

if( !is_paged()) {

	echo '<div class="home-top">';

genesis_widget_area( 'before-content', array(
		'before' => '<div class="before-content" class="widget-area">',
		'after'  => '</div>',
	) );
	
	}
}

//* Remove Featured image (if set in Theme Settings)
add_filter( 'genesis_pre_get_option_content_archive_thumbnail', 'mrs_no_post_image' );
function mrs_no_post_image() {
	return '0';
}

//* Show Excerpts regardless of Theme Settings
add_filter( 'genesis_pre_get_option_content_archive', 'mrs_show_excerpts' );
function mrs_show_excerpts() {
	return 'excerpts';
}

//* Modify the length of post excerpts
add_filter( 'excerpt_length', 'mrs_excerpt_length' );
function mrs_excerpt_length( $length ) {
	return 60; // pull first 50 words
}

//* Modify the Excerpt read more link
add_filter('excerpt_more', 'mrs_new_excerpt_more');
function mrs_new_excerpt_more($more) {
	return '... <a class="more-link" href="' . get_permalink() . '">Continue Reading...</a>';
}

//* Make sure content limit (if set in Theme Settings) doesn't apply
add_filter( 'genesis_pre_get_option_content_archive_limit', 'mrs_no_content_limit' );
function mrs_no_content_limit() {
	return '0';
}

//* Display centered wide featured image for First Post and left aligned thumbnail for the next five
add_action( 'genesis_entry_header', 'mrs_show_featured_image', 8 );
function mrs_show_featured_image() {
	if ( ! has_post_thumbnail() ) {
		return;
	}

	global $wp_query;

	if( ( $wp_query->current_post <= 0 ) ) {
		$image_args = array(
			'size' => 'blog-square-featured',
			'attr' => array(
				'class' => 'alignleft',
			),
		);
	
	} else {
		$image_args = array(
			'size' => 'blog-square-featured',
			'attr' => array(
				'class' => 'alignleft',
			),
		);
	}

	$image = genesis_get_image( $image_args );

	echo '<div class="home-featured-image"><a href="' . get_permalink() . '">' . $image .'</a></div>';
}

//* Remove entry meta
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_open', 5 );
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_close', 15 );
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

remove_action( 'genesis_entry_header', 'genesis_entry_header_markup_open', 5 );
remove_action( 'genesis_entry_header', 'genesis_entry_header_markup_close', 15 );
remove_action( 'genesis_entry_header', 'genesis_post_info', 12 );

genesis();