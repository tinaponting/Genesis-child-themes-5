<?php
//* Start the engine
require_once( get_template_directory() . '/lib/init.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'Cashmere' );

//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );

//* Add Viewport meta tag for mobile browsers
add_action( 'genesis_meta', 'sample_viewport_meta_tag' );
function sample_viewport_meta_tag() {
	echo '<meta name="viewport" content="width=device-width, initial-scale=1.0"/>';
}

//* Add support for custom background
add_theme_support( 'custom-background' );

//* Add support for custom header
add_theme_support( 'custom-header', array(
	'flex-height'     => true,
	'flex-width'      => true,
	'header-selector' => '.site-title a',
	'header-text'     => false,
	'height'          => 260,
	'width'           => 1150,
) );

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 1 );

//* Remove comment form allowed tags
add_filter( 'comment_form_defaults', 'sp_remove_comment_form_allowed_tags' );
function sp_remove_comment_form_allowed_tags( $defaults ) {
 
	$defaults['comment_notes_after'] = '';
	return $defaults;
}

//* Unregister layout setting
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );
genesis_unregister_layout( 'sidebar-content-sidebar' );
unregister_sidebar( 'header-right' );
unregister_sidebar( 'sidebar-alt' );

add_post_type_support( 'portfolio', 'genesis-cpt-archives-settings' );

//* Reposition the primary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_before_header', 'genesis_do_nav' );

//* Register
add_action( 'wp_enqueue_scripts', 'eclair_designs_scripts' );

function eclair_designs_scripts() {

wp_enqueue_script( 'eclair-mobile-menu', get_stylesheet_directory_uri() . '/js/top.js', array( 'jquery' ), '1.0.0', true );
wp_enqueue_script( 'eclair-top-button', get_stylesheet_directory_uri() . '/js/mobile-menu.js', array( 'jquery' ), '1.0.0', true );
wp_enqueue_style( 'eclair-google-fonts', '//fonts.googleapis.com/css?family=Montserrat:300,400,700|Libre+Baskerville:400,400italic,700|Poppins:300,400,500,600', array(), CHILD_THEME_VERSION );
wp_enqueue_style('font-awesome', get_stylesheet_directory_uri() . '/fontawesome/css/font-awesome.css');
wp_enqueue_script( 'eclair-fadeup', get_stylesheet_directory_uri() . '/js/fadeup.js', array( 'jquery' ), '1.0.0', true );
}

// Add To Top button
add_action( 'genesis_before', 'genesis_to_top');
	function genesis_to_top() {
	 echo '<a href="#0" class="to-top" title="Back To Top"><i class="fa fa-angle-up" aria-hidden="true"></i></a>';
}

//* Add custom social share icons
add_action( 'genesis_entry_footer', 'single_post_social_share' );
function single_post_social_share() { ?>

<div class="share">
<!-- Facebook Share -->
<a class="icon icon-facebook icon-replacement" href="http://www.facebook.com/sharer/sharer.php?s=100&p[url]=<?php echo urlencode(get_permalink()); ?>" target="_blank"><i class="fa fa-facebook"></i></a> 

<!-- Twitter Share -->
<a class="icon icon-twitter icon-replacement" href="https://twitter.com/intent/tweet?text=<?php echo urlencode(get_the_title()); ?>+<?php echo get_permalink(); ?>" target="_blank"><i class="fa fa-twitter"></i></a>

<!-- Pinterest Share -->
<a href="//pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>&amp;media=<?php echo genesis_get_image( array( 'format' => 'url' ) ); ?>&amp;description=<?php the_title(); ?>" data-pin-do="buttonPin" data-pin-config="beside"><i class="fa fa-pinterest"></i></a>

<!-- WhatsApp Share -->
<a class='WhatsApp' href="whatsapp://send?text=<?php print(urlencode(get_permalink()));?>"><i class="fa fa-whatsapp"></i></a>
</div>

   <?php
}

//* Add new featured image sizes
add_image_size( 'featured-post', 600, 400, TRUE );
add_image_size( 'popular-posts', 100, 100, true );
add_image_size( 'related', 300, 200, true );
add_image_size( 'singular-featured-thumb', 850, 520, true );
add_image_size( 'category', 500, 650, true );
add_image_size( 'box-buttons', 500, 350, true );

//* Customize the post info function
add_filter( 'genesis_post_info', 'sp_post_info_filter' );
function sp_post_info_filter($post_info) {
if ( !is_page() ) {
	
	$post_info = '[post_date]';
	
	return $post_info;
}}

//* Add Post categories above Post title on single Posts
add_action ( 'genesis_entry_header', 'eclair_category_name', 9 );
function eclair_category_name() {

	if ( !is_page() && !is_category() && !is_archive() )

	echo do_shortcode('[post_categories before=""]');
}

//* Customize the post meta function
add_filter( 'genesis_post_meta', 'sp_post_meta_filter' );
function sp_post_meta_filter($post_meta) {
if ( !is_page() ) {
	$post_meta = '[post_comments]';
	return $post_meta;
}}

//* Customize search form input button text
add_filter( 'genesis_search_button_text', 'sp_search_button_text' );
function sp_search_button_text( $text ) {
	return esc_attr( 'GO' );
}

add_filter( 'genesis_search_text', 'sp_search_text' );
function sp_search_text( $text ) {
	return esc_attr( 'Search + Enter...' );
}


//* Add Category Page
genesis_register_sidebar( array(
	'id'          => 'page-portfolio',
	'name'        => __( 'Category page','ruffled' ),
	'description' => __( 'This is the portfolio section to the Portfolio Page.','ruffled' ),
) );


//* Modify read more text
add_filter( 'the_content_more_link', 'modify_read_more_link' );
function modify_read_more_link() {
return '<a class="more-link" href="' . get_permalink() . '">READ MORE</a>';
}

//* category page 
add_action( 'genesis_before', 'remove_category_content', 0 );
function remove_category_content() {
if ( is_category( )) {
add_action( 'genesis_entry_header', 'featured_image' );
remove_action( 'genesis_entry_footer', 'single_post_social_share' );
remove_action( 'genesis_entry_header', 'genesis_entry_header_markup_open', 5 );
remove_action( 'genesis_entry_header', 'genesis_entry_header_markup_close', 15 );
remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
remove_action( 'genesis_entry_header', 'genesis_post_info', 12 );
remove_action( 'genesis_entry_content', 'genesis_do_post_content' );
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_open', 5 );
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_close', 15 );
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );
remove_action( 'genesis_entry_header', 'genesis_do_post_title' );
add_action( 'genesis_entry_content', 'genesis_do_post_title' );
}
}
function category_posts_per_page( $query ) {
if ( $query->is_category()) {
 set_query_var('posts_per_page', 9);
}
}
add_action( 'pre_get_posts', 'category_posts_per_page' );

function featured_image() {
echo '<div class="featured-image">';$large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id(), 'category' );
echo '<a href="' . get_permalink() . '"><img src="' . esc_url( $large_image_url[0] ) . '" /></a>';echo '</div>';
}

//* Modify the Genesis content limit read more link
add_filter( 'get_the_content_more_link', 'sp_read_more_link' );
function sp_read_more_link() {
	return '<a class="more-link2" href="' . get_permalink() . '">READ MORE</a>';
}

//* Eclair Designs Instagram Area

function ed_before_footer() {

if ( is_active_sidebar( 'eclair-before-footer' ) ) {
genesis_widget_area( 'eclair-before-footer', array('before' => '<div class="eclair-footer"><div class="wrap">',
	'after' => '</div></div>', ) );
}
}

add_action('genesis_before_footer', 'ed_before_footer', 11 );

genesis_register_sidebar( array(
	'id'          => 'eclair-before-footer',
	'name'        => __( 'Instagram area', 'eclairdesigns' ),
	'description' => __( 'This is the section before the footer area.', 'eclairdesigns' ),
) );

//* Message Bar

function ed_message_bar() {

if ( is_active_sidebar( 'eclair-message-bar' ) ) {
genesis_widget_area( 'eclair-message-bar', array('before' => '<div class="eclair-message"><div class="wrap">',
	'after' => '</div></div>', ) );
}
}

add_action('genesis_before_header', 'ed_message_bar');

genesis_register_sidebar( array(
	'id'          => 'eclair-message-bar',
	'name'        => __( 'Message Bar', 'eclairdesigns' ),
	'description' => __( 'Insert anything you want in this area.', 'eclairdesigns' ),
) );

//* Eclair Designs Affiliate Program

function affiliate_program() {

if ( is_front_page() && !is_paged() ) {
genesis_widget_area( 'affiliate-program', array('before' => '<div class="affiliate-program"><div class="wrap">',
	'after' => '</div></div>', ) );
}
}

add_action('genesis_before_content_sidebar_wrap', 'affiliate_program', 13 );

genesis_register_sidebar( array(
	'id'          => 'affiliate-program',
	'name'        => __( 'Affiliate Program', 'eclairdesigns' ),
	'description' => __( 'This is the section for your affiliate program widget.', 'eclairdesigns' ),
) );

//* Eclair Designs Featured Posts

function featuredposts_area() {

if ( is_front_page() && !is_paged() ) {
genesis_widget_area( 'featuredposts-area', array('before' => '<div class="featuredposts-area"><div class="wrap">',
	'after' => '</div></div>', ) );
}
}

add_action('genesis_before_content_sidebar_wrap', 'featuredposts_area', 14 );

genesis_register_sidebar( array(
	'id'          => 'featuredposts-area',
	'name'        => __( 'Featured Area B', 'eclairdesigns' ),
	'description' => __( 'This is the section for your featured posts.', 'eclairdesigns' ),
) );

//* Eclair Designs Featured Posts Section

function ed_before_content() {

if ( is_front_page() && !is_paged() ) {
genesis_widget_area( 'subscribe-section', array('before' => '<div class="subscribe-section"><div class="wrap">',
	'after' => '</div></div>', ) );
}
}

add_action('genesis_before_content_sidebar_wrap', 'ed_before_content', 15 );

genesis_register_sidebar( array(
	'id'          => 'subscribe-section',
	'name'        => __( 'Subscribe box', 'eclairdesigns' ),
	'description' => __( 'This is the section before the content area.', 'eclairdesigns' ),
) );

//* Eclair Designs Slider

function ed_before_content_wrap() {

if ( is_front_page() && !is_paged() ) {

genesis_widget_area( 'eclair-before-content-wrap', array('before' => '<div class="eclair-before-content-area"><div class="wrap"><div class="ed-wrap">',
	'after' => '</div></div></div>', ) );

}else{
return;
}
}

add_action('genesis_before_content_sidebar_wrap', 'ed_before_content_wrap', 11 );

genesis_register_sidebar( array(
	'id'          => 'eclair-before-content-wrap',
	'name'        => __( 'Home Slider', 'eclairdesigns' ),
	'description' => __( 'This is the section before content area.', 'eclairdesigns' ),
) );

//* Eclair Designs Featured Posts

function ed_after_header() {

if ( is_active_sidebar('featured-posts') ) {

genesis_widget_area( 'featured-posts', array('before' => '<div class="featured-posts"><div class="wrap"><div class="wrapwrap">',
	'after' => '</div></div></div>', ) );
}
}

add_action('genesis_before_content_sidebar_wrap', 'ed_after_header', 11 );

genesis_register_sidebar( array(
	'id'          => 'featured-posts',
	'name'        => __( 'Featured Area A', 'eclairdesigns' ),
	'description' => __( 'This is the section below header area.', 'eclairdesigns' ),
) );

// Add Social Widget Area for Primary Nav
genesis_register_sidebar( array(
	'id'          => 'nav-social-menu',
	'name'        => __( 'Nav Social Menu', 'blake' ),
	'description' => __( 'This is the nav social menu section.', 'blake' ),
) );

add_action( 'genesis_before_header', 'eclair_social_icons', 10 );

//add_filter( 'wp_nav_menu', 'eclair_social_icons', 10, 2 );

function eclair_social_icons() {
echo '<div class="socialmenu">';
echo '<div class="wrap">';
genesis_widget_area('nav-social-menu');
echo '</div>';
echo '</div>';
}

//* New widget Between Posts Area 
genesis_register_sidebar( array(
'id' => 'between-posts-area',
'name' => __( 'Between Posts Area', 'liana' ),
'description' => __( 'This widget show between and after few posts.', 'liana' ),
) );

//* Add widget area between and after 3 posts
add_action( 'genesis_after_entry', 'liana_between_posts_area' );

function liana_between_posts_area() {
global $loop_counter;

$loop_counter++;

if( $loop_counter == 3 ) {


if ( is_home() && is_active_sidebar( 'between-posts-area' ) ) {
    echo '<div class="between-posts-area widget-area"><div class="wrap">';
	dynamic_sidebar( 'between-posts-area' );
	echo '</div></div><!-- end .top -->';
	}

$loop_counter = 0;

}

}


//* Remove Existing Footer
remove_action( 'genesis_footer', 'genesis_do_footer' );

add_action( 'widgets_init', 'elle_extra_widgets' );

//* Add in new Widget area

function elle_extra_widgets() { 

 	genesis_register_sidebar( array(

 	'id' 					=> 'footercontent',
 	'name' 					=> __( 'Copyright', 'elle' ),
 	'description'			=> __( 'This is the site footer area', 'elle' ),

 ));

}
 
add_action('genesis_footer', 'elle_footer_widget'); 

//* Position the Footer Area

function elle_footer_widget() {

echo '<div class="footer-container"><div class="footer-content">';
genesis_widget_area ('footercontent');
echo '</div></div>';

}

//* add the picks function
add_action( 'genesis_entry_footer', 'my_post_picks' );
function my_post_picks() {
if ( is_single ( ) ) {
echo '<div id="affiliatewidget">'. genesis_get_custom_field('affiliate') .'</div>';
}}

//Related Posts

add_action( 'genesis_entry_footer', 'reese_related_posts', 12, 1);

function reese_related_posts() {
     
    if ( is_single ( ) ) {
         
        global $post;
 
        $count = 0;
        $postIDs = array( $post->ID );
        $related = '';
        $tags = wp_get_post_tags( $post->ID );
        $cats = wp_get_post_categories( $post->ID );
         
        if ( $tags ) {
             
            foreach ( $tags as $tag ) {
                 
                $tagID[] = $tag->term_id;
                 
            }
             
            $args = array(
                'tag__in'               => $tagID,
                'post__not_in'          => $postIDs,
                'showposts'             => 3,
                'ignore_sticky_posts'   => 1,
                'tax_query'             => array(
                    array(
                                        'taxonomy'  => 'post_format',
                                        'field'     => 'slug',
                                        'terms'     => array( 
                                            'post-format-link', 
                                            'post-format-status', 
                                            'post-format-aside', 
                                            'post-format-quote'
                                            ),
                                        'operator'  => 'NOT IN'
                    )
                )
            );
 
            $tag_query = new WP_Query( $args );
             
            if ( $tag_query->have_posts() ) {
                 
                while ( $tag_query->have_posts() ) {
                     
                    $tag_query->the_post();
 
                    $img = genesis_get_image() ? genesis_get_image( array( 'size' => 'related' ) ) : '<img src="' . get_bloginfo( 'stylesheet_directory' ) . '/images/related.png" alt="' . get_the_title() . '" />';
 
                    $related .= '<li><a href="' . get_permalink() . '" rel="bookmark" title="Permanent Link to' . get_the_title() . '">' . $img . get_the_title() . '</a></li>';
                     
                    $postIDs[] = $post->ID;
 
                    $count++;
                }
            }
        }
 
        if ( $count <= 4 ) {
             
            $catIDs = array( );
 
            foreach ( $cats as $cat ) {
                 
                if ( 3 == $cat )
                    continue;
                $catIDs[] = $cat;
                 
            }
             
            $showposts = 4 - $count;
 
            $args = array(
                'category__in'          => $catIDs,
                'post__not_in'          => $postIDs,
                'showposts'             => $showposts,
                'ignore_sticky_posts'   => 1,
                'orderby'               => 'rand',
                'tax_query'             => array(
                                    array(
                                        'taxonomy'  => 'post_format',
                                        'field'     => 'slug',
                                        'terms'     => array( 
                                            'post-format-link', 
                                            'post-format-status', 
                                            'post-format-aside', 
                                            'post-format-quote' ),
                                        'operator' => 'NOT IN'
                                    )
                )
            );
 
            $cat_query = new WP_Query( $args );
             
            if ( $cat_query->have_posts() ) {
                 
                while ( $cat_query->have_posts() ) {
                     
                    $cat_query->the_post();
 
                    $img = genesis_get_image() ? genesis_get_image( array( 'size' => 'related' ) ) : '<img src="' . get_bloginfo( 'stylesheet_directory' ) . '/images/related.png" alt="' . get_the_title() . '" />';
 
                    $related .= '<li><a href="' . get_permalink() . '" rel="bookmark" title="Permanent Link to' . get_the_title() . '">' . $img . get_the_title() . '</a></li>';
                }
            }
        }
 
        if ( $related ) {
             
            printf( '<div class="related-posts"><h4 class="related-title">RELATED</h4><ul class="related-list">%s</ul></div>', $related );
         
        }
         
        wp_reset_query();
         
    }
}

//* Add Image Upload and Color Selection to WordPress Theme Customizer
require_once( get_stylesheet_directory() . '/lib/ed-customizer.php' );

//* Include Section Image and Color CSS
include_once( get_stylesheet_directory() . '/lib/output.php' );

//* TGM plugins
require_once dirname( __FILE__ ) . '/class-tgm-plugin-activation.php';
include_once( get_stylesheet_directory() . '/tgm-in.php' );

add_theme_support( 'genesis-connect-woocommerce' );

add_action( 'after_setup_theme', 'woocommerce_support' );
function woocommerce_support() {
    add_theme_support( 'woocommerce' );
}

add_action( 'init', 'jk_remove_wc_breadcrumbs' );
function jk_remove_wc_breadcrumbs() {
    remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0 );
}

add_filter('woocommerce_product_description_heading',
'isa_product_description_heading');
 
function isa_product_description_heading() {
    return '';
}

//* Remove "Add to Cart" button on product listing page in WooCommerce
add_action( 'woocommerce_after_shop_loop_item', 'remove_add_to_cart_buttons', 1 );
 
function remove_add_to_cart_buttons() {
    remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart' );
}

//* Display 24 products per page. Goes in functions.php
add_filter( 'loop_shop_per_page', create_function( '$cols', 'return 24;' ), 20 );

remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );

//* Add this code directly, no action needed
remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );

remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
add_action( 'genesis_entry_header', 'genesis_do_post_image', 8 );

add_action( 'genesis_entry_footer', 'wpb_prev_next_post_nav_cpt' );
function wpb_prev_next_post_nav_cpt() {
	if ( ! is_singular( array( 'portfolio', 'post' ) ) )
		return;
	genesis_markup( array(
		'html5'   => '<div %s>',
		'xhtml'   => '<div class="navigation">',
		'context' => 'adjacent-entry-pagination',
	) );
	echo '<div class="pagination-previous alignleft">';
	previous_post_link();
	echo '</div>';
	echo '<div class="pagination-next alignright">';
	next_post_link();
	echo '</div>';
	echo '</div>';
}

//* Add Image Upload and Color Selection to WordPress Theme Customizer
require_once( get_stylesheet_directory() . '/lib/ed-customizer.php' );

//* Include Section Image and Color CSS
include_once( get_stylesheet_directory() . '/lib/output.php' );


/* remove wordpress version number */
remove_action('wp_head', 'wp_generator');