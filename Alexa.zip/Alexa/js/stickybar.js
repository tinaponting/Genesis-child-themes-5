( function( window, $, undefined ) {
'use strict';
  var top = $('.nav-primary').offset().top;
$(window).scroll(function(){
      if ($(this).scrollTop() > top) {
          $('.nav-primary').addClass('fixed');
      } else {
          $('.nav-primary').removeClass('fixed');
      }
  });
  
 })( this, jQuery );