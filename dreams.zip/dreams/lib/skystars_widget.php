<?php 
class My_Widget_Avatar extends WP_Widget {

	//nama widget
    public function __construct() {
        $widget_ops = array( 'classname' => 'widget_avatar', 'description' => __( "Skyandstars - About Me" ) );
        parent::__construct('my_avatar', __('Skyandstars : My About Me'), $widget_ops);
    }
	
	//input form
    function form( $instance ) {
		//Defaults
        $default = array(
            'title' => '',
			'photo_url' => '',
            'welcome_text' => ''
            
        );
		$instance = wp_parse_args((array)$instance, $default);
        $title    = $instance['title'];
        $photo_url = $instance['photo_url'];
        $welcome_text = $instance['welcome_text'];
?>
		<!-- title -->
		<p>
    <label for="<?php echo $this->get_field_id('title'); ?>">Title: 
      <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" 
             name="<?php echo $this->get_field_name('title'); ?>" type="text" 
             value="<?php echo esc_attr($title); ?>" />
    </label>
    </p>
	<!-- end -->
	<!-- image url -->
		<p>
    <label for="<?php echo $this->get_field_id('photo_url'); ?>">Image Path: 
      <input class="widefat" id="<?php echo $this->get_field_id('photo_url'); ?>" 
             name="<?php echo $this->get_field_name('photo_url'); ?>" type="text" 
             value="<?php echo esc_url($photo_url); ?>" />
			 <small style="font-style:italic">Use only square image for perfect circle crop. Upload your image first to your Media Library, copy the image url, and paste the URL here.</small>
    </label>
    </p>
	<!-- end -->
	<!-- message -->
		<p>Text :
        <textarea class="widefat" rows="16" cols="20" id="<?php echo $this->get_field_id('welcome_text'); ?>" name="<?php echo $this->get_field_name('welcome_text'); ?>"><?php echo $welcome_text; ?></textarea>
		<small style="font-style:italic">No HTML Tags</small>
		</p>
	<!-- end -->
<?php
    }
	
	//update content
    function update( $new_instance, $old_instance ) {
        $instance = $old_instance;
        $instance['title'] = $new_instance['title'];
		$instance['photo_url'] = $new_instance['photo_url'];
		$instance['welcome_text'] = $new_instance['welcome_text'];
		return $instance;
    }
	
	
	//frontend
    function widget( $args, $instance ) {
        extract($args, EXTR_SKIP);
	  $title = empty($instance['title']) ? ' ' : apply_filters('widget_title', $instance['title']);
	  $photo_url = empty($instance['photo_url']) ? '' : $instance['photo_url'];
	  $welcome_text = empty($instance['welcome_text']) ? '' : $instance['welcome_text'];
			
		echo $before_widget;
        ?>
            <div class="about-widget widget-content">
				<div class="about_wrap">
					<?php if ( isset( $instance['photo_url'] ) && !empty( $instance['photo_url'] ) ) : ?>
					<div class="circle-pp">
						<img src="<?php echo esc_url( $instance['photo_url'] ); ?>" alt="About Me"/>
					</div>
					<?php endif; ?>
					
					<?php if ( isset( $instance['title'] ) && !empty( $instance['title'] ) ) : ?>
					<h3 class="about-title"><?php echo esc_attr( $instance['title'] ); ?></h3>
					<?php endif; ?>
					
					<?php if ( isset( $instance['welcome_text'] ) && !empty( $instance['welcome_text'] ) ) : ?>
					<div class="about-p"><p><?php echo esc_attr( $instance['welcome_text'] ); ?></p></div>
					<?php endif; ?>
				</div>
        </div>
		
        <?php
        echo $after_widget;
    }

	
	
}

function lbi_widgets_init() {
    register_widget( 'My_Widget_Avatar' );
}
add_action( 'widgets_init', 'lbi_widgets_init' );
?>