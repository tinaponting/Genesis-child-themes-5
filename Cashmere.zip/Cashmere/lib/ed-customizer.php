<?php
/**
 * @subpackage Customizations
 */
 

function ruffled_primarymenu()  {
	return '#f9f6f6';
}

function ruffled_primarytext()  {
	return '#000';
}

function ruffled_secondarymenu() {
	return '#fff';
}

function ruffled_secondarytext() {
	return '#000';
}

function ruffled_fontscolor() {
	return '#000';
}

function ruffled_bodycolor() {
	return '#000';
}

function ruffled_categorieslink() {
	return '#b98a68';
}

function ruffled_dateheader() {
	return '#000';
}

function ruffled_readmoretag() {
	return '#000';
}

function ruffled_linkagecolor() {
	return '#b98a68';
}

function ruffled_sharebutton() {
	return '#b98a68';
}

function ruffled_buttoncolor() {
	return '#b98a68';
}

function ruffled_enewsbackground() {
	return '#f9f6f6';
}

function ruffled_hovercolor() {
	return '#adadad';
}

function backtotop_color() {
	return '#adadad';
}

add_action( 'customize_register', 'ruffled_customizer' );

function ruffled_customizer(){

	global $wp_customize;
	
	$wp_customize->add_setting(
		'ruffled_primary_menu',
		array(
			'default' => ruffled_primarymenu(),
		)
	);

	$wp_customize->add_setting(
		'ruffled_primary_text',
		array(
			'default' => ruffled_primarytext(),
		)
	);

	$wp_customize->add_setting(
		'ruffled_secondary_menu',
		array(
			'default' => ruffled_secondarymenu(),
		)
	);
	
	
	$wp_customize->add_setting(
		'backtotopcolor',
		array(
			'default' => backtotop_color(),
		)
	);

		$wp_customize->add_setting(
		'ruffled_secondary_text',
		array(
			'default' => ruffled_secondarytext(),
		)
	);
	
	$wp_customize->add_setting(
		'ruffled_fonts_color',
		array(
			'default' => ruffled_fontscolor(),
		)
	);

	$wp_customize->add_setting(
		'ruffled_body_color',
		array(
			'default' => ruffled_bodycolor(),
		)
	);

	$wp_customize->add_setting(
		'ruffled_categories_link',
		array(
			'default' => ruffled_categorieslink(),
		)
	);

	$wp_customize->add_setting(
		'ruffled_date_header',
		array(
			'default' => ruffled_dateheader(),
		)
	);

	$wp_customize->add_setting(
		'ruffled_read_more',
		array(
			'default' => ruffled_readmoretag(),
		)
	);

		$wp_customize->add_setting(
		'ruffled_linkage_color',
		array(
			'default' => ruffled_linkagecolor(),
		)
	);

	$wp_customize->add_setting(
		'ruffled_share_button',
		array(
			'default' => ruffled_sharebutton(),
		)
	);

	$wp_customize->add_setting(
		'ruffled_button_color',
		array(
			'default' => ruffled_buttoncolor(),
		)
	);

	$wp_customize->add_setting(
		'ruffled_enews_background',
		array(
			'default' => ruffled_enewsbackground(),
		)
	);

	$wp_customize->add_setting(
		'ruffled_hover',
		array(
			'default' => ruffled_hovercolor(),
		)
	);

	$wp_customize->add_section(  'ruffled_blogstyle',  array(
				'title'      		=> __( 'Blog Post Style', 'Ruffled' ),				
				'description'		=> __('Manage the layout of blog listing.', 'Ruffled'),
				'priority'		=> 3
			)
		);

	$wp_customize->add_setting( 'ruffled_blog_style', array(
				'default'   		=> 'default',
				'capability'     => 'edit_theme_options',
				'transport' 		=> 'refresh',				
		)
	);


	$wp_customize->add_control(
			'ruffled_blog_style', array(
				'label'     		=> __('Blog Post Style', 'Ruffled'),
				'description'		=> 'Manage the layout of blog listing.',
				'section'   		=> 'ruffled_blogstyle',
				'settings'  		=> 'ruffled_blog_style',
				'type'      		=> 'select',
				'choices'   		=> array(
					'default'     		=> __( 'default', 'Ruffled' ),
					'list'      		=> __( 'list', 'Ruffled' ),
					'grid'        		=> __( 'grid', 'Ruffled' ),
				)
			)
		);	

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'ruffled_primary_menu',
			array(
			    'description' => __( 'Customize the default background color of the primary menu bar.', 'ruffled' ),
			    'label'       => __( 'Primary Menu Bar', 'Ruffled' ),
			    'section'     => 'colors',
			    'settings'    => 'ruffled_primary_menu',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'ruffled_primary_text',
			array(
			    'description' => __( 'Customize the default background color of the primary menu text.', 'ruffled' ),
			    'label'       => __( 'Primary Menu Text Color', 'Ruffled' ),
			    'section'     => 'colors',
			    'settings'    => 'ruffled_primary_text',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'ruffled_secondary_menu',
			array(
			    'description' => __( 'Customize the default background color of the secondary menu bar.', 'Ruffled' ),
			    'label'       => __( 'Secondary Menu Bar', 'Ruffled' ),
			    'section'     => 'colors',
			    'settings'    => 'ruffled_secondary_menu',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'ruffled_secondary_text',
			array(
			    'description' => __( 'Customize the default background color of the secondary menu text.', 'ruffled' ),
			    'label'       => __( 'Secondary Menu Text Color', 'Ruffled' ),
			    'section'     => 'colors',
			    'settings'    => 'ruffled_secondary_text',
			)
		)
	);


	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'ruffled_fonts_color',
			array(
			    'description' => __( 'Customize the default background color of the box button title.', 'Ruffled' ),
			    'label'       => __( 'Title Color', 'Ruffled' ),
			    'section'     => 'colors',
			    'settings'    => 'ruffled_fonts_color',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'ruffled_body_color',
			array(
			    'description' => __( 'Customize the default color of the body text.', 'Ruffled' ),
			    'label'       => __( 'Body Text Color', 'Ruffled' ),
			    'section'     => 'colors',
			    'settings'    => 'ruffled_body_color',
			)
		)
	);

$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'ruffled_categories_link',
			array(
			    'description' => __( 'Customize the default color of the categories link.', 'Ruffled' ),
			    'label'       => __( 'Categories Link', 'Ruffled' ),
			    'section'     => 'colors',
			    'settings'    => 'ruffled_categories_link',
			)
		)
	);

$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'ruffled_date_header',
			array(
			    'description' => __( 'Customize the default color of the date header.', 'Ruffled' ),
			    'label'       => __( 'Date Header', 'Ruffled' ),
			    'section'     => 'colors',
			    'settings'    => 'ruffled_date_header',
			)
		)
	);

$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'ruffled_read_more',
			array(
			    'description' => __( 'Customize the default background color of the read more tag.', 'Ruffled' ),
			    'label'       => __( 'Read More Button', 'Ruffled' ),
			    'section'     => 'colors',
			    'settings'    => 'ruffled_read_more',
			)
		)
	);

$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'ruffled_linkage_color',
			array(
			    'description' => __( 'Customize the default color of the links.', 'Ruffled' ),
			    'label'       => __( 'Linkage Color', 'Ruffled' ),
			    'section'     => 'colors',
			    'settings'    => 'ruffled_linkage_color',
			)
		)
	);

$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'ruffled_share_button',
			array(
			    'description' => __( 'Customize the default color of the share buttons.', 'Ruffled' ),
			    'label'       => __( 'Share Button Color', 'Ruffled' ),
			    'section'     => 'colors',
			    'settings'    => 'ruffled_share_button',
			)
		)
	);

$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'ruffled_button_color',
			array(
			    'description' => __( 'Customize the default color of the buttons.', 'Ruffled' ),
			    'label'       => __( 'Button Color', 'Ruffled' ),
			    'section'     => 'colors',
			    'settings'    => 'ruffled_button_color',
			)
		)
	);
	
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'backtotopcolor',
			array(
			    'description' => __( 'Customize the default color of the back to top button.', 'Ruffled' ),
			    'label'       => __( 'Back To Top Button', 'Ruffled' ),
			    'section'     => 'colors',
			    'settings'    => 'backtotopcolor',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'ruffled_enews_background',
			array(
			    'description' => __( 'Customize the default color of the Genesis eNews Extended subscription box on the sidebar.', 'Ruffled' ),
			    'label'       => __( 'Subscription Background Color', 'Ruffled' ),
			    'section'     => 'colors',
			    'settings'    => 'ruffled_enews_background',
			)
		)
	);

$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'ruffled_hover',
			array(
			    'description' => __( 'Customize the default color of the hover color.', 'Ruffled' ),
			    'label'       => __( 'Hover Color', 'Ruffled' ),
			    'section'     => 'colors',
			    'settings'    => 'ruffled_hover',
			)
		)
	);
}