<?php
/**
 * This file adds the custom portfolio post type single post template.
 *
 */

// Add custom body class to the head
add_filter( 'body_class', 'fairlight_add_body_class' );
function fairlight_add_body_class( $classes ) {
   $classes[] = 'single-portfolio';
   return $classes;
}

//* Force full width content layout
add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );

//* Remove the breadcrumb navigation
remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );

//* Remove the author box on single posts
remove_action( 'genesis_after_entry', 'genesis_do_author_box_single', 8 );

//* Remove the post meta function
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

//* Remove the post info function
remove_action( 'genesis_entry_header', 'genesis_post_info', 12 );

//* Previous and Next Post navigation
add_action('genesis_after_entry', 'sk_custom_post_nav');
function sk_custom_post_nav() {

	echo '<div class="prev-next-post-links">';
		previous_post_link('<div class="previous-post-link">&laquo; %link</div>', '<strong>%title</strong>' );
		next_post_link('<div class="next-post-link">%link &raquo;</div>', '<strong>%title</strong>' );
	echo '</div>';

}

genesis();