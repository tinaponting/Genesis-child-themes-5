<?php

/**
 * @author Eclair Designs
 * @package Elle
 * @subpackage Customizations
 */
 

function elle_customizer_get_default_primary_color() {
	return '#000';
}

function elle_customizer_get_default_accent_color() {
	return '#b09b6d';
}

add_action( 'customize_register', 'elle_customizer' );

function elle_customizer(){

	global $wp_customize;
	
	$wp_customize->add_setting(
		'elle_primary_color',
		array(
			'default' => elle_customizer_get_default_primary_color(),
		)
	);

	$wp_customize->add_setting(
		'elle_accent_color',
		array(
			'default' => elle_customizer_get_default_accent_color(),
		)
	);
	
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'elle_primary_color',
			array(
			    'description' => __( 'Customize the default primary color for buttons background color, post title color and more.', 'elle' ),
			    'label'       => __( 'Primary Color', 'elle' ),
			    'section'     => 'colors',
			    'settings'    => 'elle_primary_color',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'elle_accent_color',
			array(
			    'description' => __( 'Customize the default accent color for links, hover color, and more.', 'elle' ),
			    'label'       => __( 'Accent Color', 'elle' ),
			    'section'     => 'colors',
			    'settings'    => 'elle_accent_color',
			)
		)
	);

}
