<?php
/*
Plugin Name: CopyProof WordPress Website
Plugin URI: https://teskedsgumman.se 
Description: Only PlugIn activation is enough! No need to use any short-code or to edit settings.
 */
 
// Prevent direct file access
if ( ! defined ( 'ABSPATH' ) ) {exit;
}
function tawhidurrahmandearthirtyeight()
{
			<?php
?> 	
<script type="text/javascript">
	document.onkeydown = function (event) {
        event = (event || window.event);
        if (event.keyCode == 67) {
            return false;
        }
    }
    </script>
<script type="text/javascript">
window.addEventListener("keydown",function(e){if(e.ctrlKey&&(e.which==65||e.which==66||e.which==67||e.which==70||e.which==73||e.which==80||e.which==83||e.which==85||e.which==86)){e.preventDefault()}});document.keypress=function(e){if(e.ctrlKey&&(e.which==65||e.which==66||e.which==70||e.which==67||e.which==73||e.which==80||e.which==83||e.which==85||e.which==86)){}return false}
</script>

<script type="text/javascript">
document.onkeydown=function(e){e=e||window.event;if(e.keyCode==123||e.keyCode==18){return false}}
</script>

<script type="text/javascript">
function disableSelection(e){if(typeof e.onselectstart!="undefined")e.onselectstart=function(){return false};else if(typeof e.style.MozUserSelect!="undefined")e.style.MozUserSelect="none";else e.onmousedown=function(){return false};e.style.cursor="default"}window.onload=function(){disableSelection(document.body)}
</script>

<script type="text/javascript">
		function md(e) 
		{ 
		  try { if (event.button==2||event.button==3) return false; }  
		  catch (e) { if (e.which == 3) return false; } 
		}
		document.oncontextmenu = function() { return false; }
		document.ondragstart = function() { return false; }
		document.onmousedown = md;
		
// The CONFIG:
var disable_right_click = /* If this was true, the user cannot right click and if they do, they see alert DevTools? */ true;
var disable_F3 = /* If this was true, users cannot do f3 */ true;
var disable_f12 = /* If this was true, users cannot do f12 */ true;
var disable_csi = /* if this was true, users cannot do control shift i */ true;
var disable_J = /* If this was true, users cannot do CtrJ */ true;
var disable_C = /* If this was true, users cannot do fC */ true;
var disable_A = /* If this was true, users cannot do Ctrl+A */ true;
var disable_C = /* If this was true, users cannot do Ctrl+C */ true;
var disable_U = /* If this was true, users cannot do Ctrl+U */ true;
var disable_S = /* If this was true, users cannot do Ctrl+S */ true;
var disable_A = /* If this was true, users cannot do Ctrl+A */ true;
var disable_P = /* If this was true, users cannot do Ctrl+P */ true;
var disable_f = /* If this was true, users cannot do Ctrl+J */ true;
var disable_x = /* If this was true, users cannot do Ctrl+X */ true;
var disable_V = /* If this was true, users cannot do Ctrl+V */ true;
var disable_F = /* If this was true, users cannot do Ctrl+F */ true;
var disable_K = /* If this was true, users cannot do Ctrl+K */ true;
var disable_I = /* If this was true, users cannot do Ctrl+I */ true;
var disable_J = /* If this was true, users cannot do Ctrl+J */ true;
var disable_X = /* If this was true, users cannot do Ctrl+X */ true;
document.onkeydown = function(event) {
    if (disable_f12 == true){
        if (event.keyCode == 123) {
              event.preventDefault();
        }
    }
    if (disable_csi == true){
        if (event.ctrlKey && event.shiftKey && event.keyCode == 73) {
            event.preventDefault();
        }
    }
    if (disable_f3 == true){
       if (event.keyCode == 53) {
           event.preventDefault();
        }
    }
    if (disable_CtrlJ == true){
        if (event.ctrlKey && event.shiftKey && event.keyCode == 74) {
            event.preventDefault();
        }
    }
    if (disable_CtrlA == true){
        if (event.ctrlKey && event.shiftKey && event.keyCode == 65) {
            event.preventDefault();
        }
    }
    if (disable_CtrlC == true){
        if (event.ctrlKey && event.shiftKey && event.keyCode == 67) {
            event.preventDefault();
        }
   }
   if (disable_CtrlU == true){
       if (event.ctrlKey && event.shiftKey && event.keyCode == 85) {
           event.preventDefault();
        }
   }
   if (disable_CtrlS == true){
      if (event.ctrlKey && event.shiftKey && event.keyCode == 65) {
          event.preventDefault();
        }
   }
    if (disable_CtrlA == true){
        if (event.ctrlKey && event.shiftKey && event.keyCode == 65) {
           event.preventDefault();
        }
    }
    if (disable_CtrlP == true){
        if (event.ctrlKey && event.shiftKey && event.keyCode == 80) {
            event.preventDefault();
        }
    }
    if (disable_Ctrlf == true){
       if (event.ctrlKey && event.shiftKey && event.keyCode == 13) {
           event.preventDefault();
        }
    }
    if (disable_Ctrlx == true){
        if (event.ctrlKey && event.shiftKey && event.keyCode == 88) {
           event.preventDefault();
        }
    }
    if (disable_CtrlV == true){
        if (event.ctrlKey && event.shiftKey && event.keyCode == 86) {
           event.preventDefault();
        }
    }
    if (disable_CtrlF == true){
        if (event.ctrlKey && event.shiftKey && event.keyCode == 70) {
           event.preventDefault();
      }
   }
   if (disable_K == true){
       if (event.keyCode == 75) {
           event.preventDefault();
        }
    }
    if (disable_I == true){
        if (event.keyCode == 73) {
           event.preventDefault();
        }
    }
        if (disable_I == true){
        if (event.keyCode == 73) {
           event.preventDefault();
        }
    }
    if (disable_J == true){
       if (event.keyCode == 88) {
           event.preventDefault();
        }
    }
if (disable_right_click == true){
    document.oncontextmenu = function() {
        event.preventDefault();
        alert("Devtools?");
     }
   }
}
function killCopy(e){
    return false;
}
function reEnable(){
    return true;
}
document.onselectstart=new Function ("return false");
if (window.sidebar){
    document.onmousedown=killCopy;
    document.onclick=reEnable;
}

// Disable View Source
if (ccpdrc_settings && ccpdrc_settings.view_source) {
  document.onmousedown = function (event) {
    event = (event || window.event);
    if (event.keyCode === 123) {
      if (ccpdrc_settings.view_source_message) ccpdrc_show_snackbar(ccpdrc_settings.view_source_message);
      return false;
    }
  }
  document.onkeydown = function (event) {
    event = (event || window.event);
    if (event.keyCode === 123 ||
      event.ctrlKey && event.shiftKey && event.keyCode === 73 ||
      event.ctrlKey && event.shiftKey && event.keyCode === 75) {
      if (ccpdrc_settings.view_source_message) ccpdrc_show_snackbar(ccpdrc_settings.view_source_message);
      return false;
    }
    if (event.ctrlKey && event.keyCode === 85) {
      if (ccpdrc_settings.view_source_message) ccpdrc_show_snackbar(ccpdrc_settings.view_source_message);
      return false;
    }
    if (event.ctrlKey && event.altKey && event.keyCode === 73) {
      if (ccpdrc_settings.view_source_message) ccpdrc_show_snackbar(ccpdrc_settings.view_source_message);
      return false;
    }
    if (event.metaKey && event.altKey && event.keyCode === 73) {
      if (ccpdrc_settings.view_source_message) ccpdrc_show_snackbar(ccpdrc_settings.view_source_message);
      return false;
    }
    if (event.metaKey && event.altKey && event.keyCode === 85) {
      if (ccpdrc_settings.view_source_message) ccpdrc_show_snackbar(ccpdrc_settings.view_source_message);
      return false;
    }
  }
  document.onkeypress = function (event) {
    event = (event || window.event);
    if (event.keyCode === 123) {
      if (ccpdrc_settings.view_source_message) ccpdrc_show_snackbar(ccpdrc_settings.view_source_message);
      return false;
    }
  }
}

// Disable Mobilde view
{
  const isMobile = window.navigator.userAgent.match(/mobi/i);
  if (!isMobile) {
      document.addEventListener("contextmenu", function(event) {
        var notInput = (event.target || event.srcElement).tagName.toLowerCase() !== "input" && (event.target || event.srcElement).tagName.toLowerCase() !== "textarea";
        if (notInput) {
          event.preventDefault();
        }
      });
        document.addEventListener("contextmenu", function(event) {
          var notInput = (event.target || event.srcElement).tagName.toLowerCase() !== "input" && (event.target || event.srcElement).tagName.toLowerCase() !== "textarea";
          if (notInput && (event.target || event.srcElement).innerText) {
            event.preventDefault();
          }
        });
        const textProtectionStyle = document.createElement("style");
        textProtectionStyle.type = "text/css";
        textProtectionStyle.innerHTML = 'body {' +
            '-webkit-touch-callout: none;' +
            '-webkit-user-select: none;' +
            '-khtml-user-select: none;' +
            '-moz-user-select: none;' +
            '-ms-user-select: none;' +
            'user-select: none;' +
          '}' +
          '.powr-countdown-timer iframe {' +
            'pointer-events: none;' +
          '}';
        document.head.appendChild(textProtectionStyle);
        document.addEventListener("mousedown", function(event) {
          if ((event.target || event.srcElement).tagName.toLowerCase() === "img") {
            if (event.which == 2) {
              event.preventDefault();
            }
          }
        });
        document.addEventListener("contextmenu", function(event) {
          if ((event.target || event.srcElement).tagName.toLowerCase() === "img") {
            event.preventDefault();
          }
        });
        const imageDragStyle = document.createElement("style");
        imageDragStyle.type = "text/css";
        imageDragStyle.innerHTML = 'img {' +
            '-webkit-user-drag: none;' +
            'user-drag: none;' +
          '}';
        document.head.appendChild(imageDragStyle);
        const disableDragAndDrop = function(){
          document.body.setAttribute("ondragstart", "return false;");
          document.body.setAttribute("ondrop", "return false;");
        };
        if (document.readyState === "complete" || document.readyState === "interactive") {
          disableDragAndDrop();
        } else {
          document.addEventListener("DOMContentLoaded", disableDragAndDrop);
        }
        document.addEventListener("contextmenu", function(event) {
          if ((event.target || event.srcElement).style.backgroundImage) {
            event.preventDefault();
          }
        });
        document.addEventListener("copy", function(event) {
          if (
            (event.target || event.srcElement).tagName.toLowerCase() !== "input" &&
            (event.target || event.srcElement).tagName.toLowerCase() !== "textarea"
          ) {
            event.preventDefault();
          }
        });
        document.addEventListener("cut", function(event) {
          if (
            (event.target || event.srcElement).tagName.toLowerCase() != "input" &&
            (event.target || event.srcElement).tagName.toLowerCase() != "textarea"
          ) {
            event.preventDefault();
          }
        });
  } else {
        const bodySelectStyle = document.createElement("style");
        bodySelectStyle.type = "text/css";
        bodySelectStyle.innerHTML = 'body {' +
            '-webkit-touch-callout: none;' +
            '-webkit-user-select: none;' +
            '-khtml-user-select: none;' +
            '-moz-user-select: none;' +
            '-ms-user-select: none;' +
            'user-select: none;' +
          '}';
        document.head.appendChild(bodySelectStyle);
        const imageSelectStyle = document.createElement("style");
        imageSelectStyle.type = "text/css";
        imageSelectStyle.innerHTML = 'img {' +
            '-webkit-touch-callout: none;' +
            '-webkit-user-select: none;' +
            '-khtml-user-select: none;' +
            '-moz-user-select: none;' +
            '-ms-user-select: none;' +
            'user-select: none;' +
            'pointer-events: none;' +
          '}' +
          /* In the case: <a href=''><img /></a>, pointer-events: none will
          break links.
          'a > img {' +
            'pointer-events: auto;' +
          '}' +
          /* Specific fix for FlexSlider */
          '.flex-control-thumbs li > img {' +
            'pointer-events: auto;' +
          '}' +
          'ryviu-widget li > img {' +
            'pointer-events: auto;' +
          '}';
        document.head.appendChild(imageSelectStyle);
        document.addEventListener("contextmenu", function(event) {
          if ((event.target || event.srcElement).tagName.toLowerCase() === "img") {
            event.preventDefault();
          }
        });
  }
}

        /**
         * Disable Text Selection.
         * Disable Text Highlight (Text Selection) by Mouse.
         **/
        function disableTextSelection() {
            if ( typeof document.body.onselectstart != 'undefined' ){
                document.body.onselectstart = function(){ return false; };
            } else if ( typeof document.body.style.MozUserSelect !== 'undefined' ) {
                document.body.style.MozUserSelect = 'none';
            } else if ( typeof document.body.style.webkitUserSelect !== 'undefined' ) {
                document.body.style.webkitUserSelect = 'none';
            } else {
                document.body.onmousedown = function(){ return false; };
            }
            /** Skip css layer for Safari. */
            if ( navigator.userAgent.search( "Safari" ) >= 0 && navigator.userAgent.search( "Chrome" ) < 0 ) { return; }

            /** Add css layer protection. */
            document.documentElement.style.webkitTouchCallout = "none";
            // noinspection JSDeprecatedSymbols
            document.documentElement.style.webkitUserSelect = "none";
            let css = document.createElement( 'style' );
            css.type = 'text/css';
            css.innerText = `
            *:not(input):not(textarea):not([contenteditable=""]):not([contenteditable="true"]) {
                -webkit-user-select: none !important;
                -moz-user-select: none !important;
                -ms-user-select: none !important;
                user-select: none !important;
            }`;
            document.head.appendChild( css );

        }

        /**
         * Disable Image Dragging by Mouse.
         **/
        function disableImageDragging() {
            document.ondragstart = function() {
                return false;
            };
        }

        /**
         * Disable CTRL|CMD + Key by key Code.
         **/
        function disable_key( code ) {
            window.addEventListener( 'keydown', function( e ) {

                /** For Windows Check CTRL. */
                // noinspection JSDeprecatedSymbols
                if ( e.ctrlKey && e.which === code ) {
                    e.preventDefault();
                }

                /** For Mac Check Metakey. */
                // noinspection JSDeprecatedSymbols
                if ( e.metaKey && e.which === code ) {
                    e.preventDefault();
                }
            } );
            document.keypress = function( e ) {

                /** For Windows Check CTRL. */
                if ( e.ctrlKey && e.which === code ) {
                    return false;
                }
                /** For Mac Check Metakey. */
                if ( e.metaKey && e.which === code ) {
                    return false;
                }
            };
        }
        return {
            init: init( options )
        };
    }

/*!
 * hotkeys-js v3.8.5
 * A simple micro-library for defining and dispatching keyboard shortcuts. It has no dependencies.
 */
(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory() :
        typeof define === 'function' && define.amd ? define(factory) :
            (global = typeof globalThis !== 'undefined' ? globalThis : global || self, global.hotkeys = factory());
}(this, (function () { 'use strict';
    var isff = typeof navigator !== 'undefined' ? navigator.userAgent.toLowerCase().indexOf('firefox') > 0 : false; // 绑定事件
    function addEvent(object, event, method) {
        if (object.addEventListener) {
            object.addEventListener(event, method, false);
        } else if (object.attachEvent) {
            object.attachEvent("on".concat(event), function () {
                method(window.event);
            });
        }
    }
    function getMods(modifier, key) {
        var mods = key.slice(0, key.length - 1);
        for (var i = 0; i < mods.length; i++) {
            mods[i] = modifier[mods[i].toLowerCase()];
        }
        return mods;
    }
    function getKeys(key) {
        if (typeof key !== 'string') key = '';
        key = key.replace(/\s/g, '');
        var keys = key.split(',');
        var index = keys.lastIndexOf('');
        for (; index >= 0;) {
            keys[index - 1] += ',';
            keys.splice(index, 1);
            index = keys.lastIndexOf('');
        }
        return keys;
    }
    function compareArray(a1, a2) {
        var arr1 = a1.length >= a2.length ? a1 : a2;
        var arr2 = a1.length >= a2.length ? a2 : a1;
        var isIndex = true;
        for (var i = 0; i < arr1.length; i++) {
            if (arr2.indexOf(arr1[i]) === -1) isIndex = false;
        }
        return isIndex;
    }
    var _keyMap = {
        backspace: 8,
        tab: 9,
        clear: 12,
        enter: 13,
        return: 13,
        esc: 27,
        escape: 27,
        space: 32,
        left: 37,
        up: 38,
        right: 39,
        down: 40,
        del: 46,
        delete: 46,
        ins: 45,
        insert: 45,
        home: 36,
        end: 35,
        pageup: 33,
        pagedown: 34,
        capslock: 20,
        num_0: 96,
        num_1: 97,
        num_2: 98,
        num_3: 99,
        num_4: 100,
        num_5: 101,
        num_6: 102,
        num_7: 103,
        num_8: 104,
        num_9: 105,
        num_multiply: 106,
        num_add: 107,
        num_enter: 108,
        num_subtract: 109,
        num_decimal: 110,
        num_divide: 111,
        '⇪': 20,
        ',': 188,
        '.': 190,
        '/': 191,
        '`': 192,
        '-': isff ? 173 : 189,
        '=': isff ? 61 : 187,
        ';': isff ? 59 : 186,
        '\'': 222,
        '[': 219,
        ']': 221,
        '\\': 220
    };
    var _modifier = {
        // shiftKey
        '⇧': 16,
        shift: 16,
        // altKey
        '⌥': 18,
        alt: 18,
        option: 18,
        // ctrlKey
        '⌃': 17,
        ctrl: 17,
        control: 17,
        // metaKey
        '⌘': 91,
        cmd: 91,
        command: 91
    };
    var modifierMap = {
        16: 'shiftKey',
        18: 'altKey',
        17: 'ctrlKey',
        91: 'metaKey',
        shiftKey: 16,
        ctrlKey: 17,
        altKey: 18,
        metaKey: 91
    };
    var _mods = {
        16: false,
        18: false,
        17: false,
        91: false
    };
    var _handlers = {}; // F1~F12 special key
    for (var k = 1; k < 20; k++) {
        _keyMap["f".concat(k)] = 111 + k;
    }
    var _downKeys = [];
    var _scope = 'all';
    var elementHasBindEvent = [];
    var code = function code(x) {
        return _keyMap[x.toLowerCase()] || _modifier[x.toLowerCase()] || x.toUpperCase().charCodeAt(0);
    };
    function setScope(scope) {
        _scope = scope || 'all';
    }
    function getScope() {
        return _scope || 'all';
    }
    function getPressedKeyCodes() {
        return _downKeys.slice(0);
    }
    function filter(event) {
        var target = event.target || event.srcElement;
        var tagName = target.tagName;
        var flag = true; // ignore: isContentEditable === 'true', <input> and <textarea> when readOnly state is false, <select>
        if (target.isContentEditable || (tagName === 'INPUT' || tagName === 'TEXTAREA' || tagName === 'SELECT') && !target.readOnly) {
            flag = false;
        }
        return flag;
    }
    function isPressed(keyCode) {
        if (typeof keyCode === 'string') {
            keyCode = code(keyCode);
        }
        return _downKeys.indexOf(keyCode) !== -1;
    }
    function deleteScope(scope, newScope) {
        var handlers;
        var i;
        if (!scope) scope = getScope();
        for (var key in _handlers) {
            if (Object.prototype.hasOwnProperty.call(_handlers, key)) {
                handlers = _handlers[key];

                for (i = 0; i < handlers.length;) {
                    if (handlers[i].scope === scope) handlers.splice(i, 1);else i++;
                }
            }
        }
        if (getScope() === scope) setScope(newScope || 'all');
    }
    function clearModifier(event) {
        var key = event.keyCode || event.which || event.charCode;
        var i = _downKeys.indexOf(key); // 从列表中清除按压过的键
        if (i >= 0) {
            _downKeys.splice(i, 1);
        }
        if (event.key && event.key.toLowerCase() === 'meta') {
            _downKeys.splice(0, _downKeys.length);
        }
        if (key === 93 || key === 224) key = 91;
        if (key in _mods) {
            _mods[key] = false;
            for (var k in _modifier) {
                if (_modifier[k] === key) hotkeys[k] = false;
            }
        }
    }
    function unbind(keysInfo) {
        // unbind(), unbind all keys
        if (!keysInfo) {
            Object.keys(_handlers).forEach(function (key) {
                return delete _handlers[key];
            });
        } else if (Array.isArray(keysInfo)) {
            // support like : unbind([{key: 'ctrl+a', scope: 's1'}, {key: 'ctrl-a', scope: 's2', splitKey: '-'}])
            keysInfo.forEach(function (info) {
                if (info.key) eachUnbind(info);
            });
        } else if (typeof keysInfo === 'object') {
            // support like unbind({key: 'ctrl+a, ctrl+b', scope:'abc'})
            if (keysInfo.key) eachUnbind(keysInfo);
        } else if (typeof keysInfo === 'string') {
            for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
                args[_key - 1] = arguments[_key];
            }
            // support old method
            // eslint-disable-line
            var scope = args[0],
                method = args[1];
            if (typeof scope === 'function') {
                method = scope;
                scope = '';
            }
            eachUnbind({
                key: keysInfo,
                scope: scope,
                method: method,
                splitKey: '+'
            });
        }
    }
    var eachUnbind = function eachUnbind(_ref) {
        var key = _ref.key,
            scope = _ref.scope,
            method = _ref.method,
            _ref$splitKey = _ref.splitKey,
            splitKey = _ref$splitKey === void 0 ? '+' : _ref$splitKey;
        var multipleKeys = getKeys(key);
        multipleKeys.forEach(function (originKey) {
            var unbindKeys = originKey.split(splitKey);
            var len = unbindKeys.length;
            var lastKey = unbindKeys[len - 1];
            var keyCode = lastKey === '*' ? '*' : code(lastKey);
            if (!_handlers[keyCode]) return;
            if (!scope) scope = getScope();
            var mods = len > 1 ? getMods(_modifier, unbindKeys) : [];
            _handlers[keyCode] = _handlers[keyCode].map(function (record) {
                var isMatchingMethod = method ? record.method === method : true;
                if (isMatchingMethod && record.scope === scope && compareArray(record.mods, mods)) {
                    return {};
                }
                return record;
            });
        });
    };
    function eventHandler(event, handler, scope) {
        var modifiersMatch;
        if (handler.scope === scope || handler.scope === 'all') {
            modifiersMatch = handler.mods.length > 0;
            for (var y in _mods) {
                if (Object.prototype.hasOwnProperty.call(_mods, y)) {
                    if (!_mods[y] && handler.mods.indexOf(+y) > -1 || _mods[y] && handler.mods.indexOf(+y) === -1) {
                        modifiersMatch = false;
                    }
                }
            }
            if (handler.mods.length === 0 && !_mods[16] && !_mods[18] && !_mods[17] && !_mods[91] || modifiersMatch || handler.shortcut === '*') {
                if (handler.method(event, handler) === false) {
                    if (event.preventDefault) event.preventDefault();else event.returnValue = false;
                    if (event.stopPropagation) event.stopPropagation();
                    if (event.cancelBubble) event.cancelBubble = true;
                }
            }
        }
    }
    function dispatch(event) {
        var asterisk = _handlers['*'];
        var key = event.keyCode || event.which || event.charCode;
        if (!hotkeys.filter.call(this, event)) return;
        if (key === 93 || key === 224) key = 91;
        /**
         * Collect bound keys
         */
        if (_downKeys.indexOf(key) === -1 && key !== 229) _downKeys.push(key);
        /**
         * Jest test cases are required.
         * ===============================
         */
        ['ctrlKey', 'altKey', 'shiftKey', 'metaKey'].forEach(function (keyName) {
            var keyNum = modifierMap[keyName];
            if (event[keyName] && _downKeys.indexOf(keyNum) === -1) {
                _downKeys.push(keyNum);
            } else if (!event[keyName] && _downKeys.indexOf(keyNum) > -1) {
                _downKeys.splice(_downKeys.indexOf(keyNum), 1);
            } else if (keyName === 'metaKey' && event[keyName] && _downKeys.length === 3) {
                /**
                 * Fix if Command is pressed:
                 * ===============================
                 */
                if (!(event.ctrlKey || event.shiftKey || event.altKey)) {
                    _downKeys = _downKeys.slice(_downKeys.indexOf(keyNum));
                }
            }
        });
        /**
         * -------------------------------
         */
        if (key in _mods) {
            _mods[key] = true;
            for (var k in _modifier) {
                if (_modifier[k] === key) hotkeys[k] = true;
            }
            if (!asterisk) return;
        }
        for (var e in _mods) {
            if (Object.prototype.hasOwnProperty.call(_mods, e)) {
                _mods[e] = event[modifierMap[e]];
            }
        }
        /**
         * https://github.com/jaywcjlove/hotkeys/pull/129
         * This solves the issue in Firefox on Windows where hotkeys corresponding to special characters would not trigger.
         * An example of this is ctrl+alt+m on a Swedish keyboard which is used to type μ.
         */
        if (event.getModifierState && !(event.altKey && !event.ctrlKey) && event.getModifierState('AltGraph')) {
            if (_downKeys.indexOf(17) === -1) {
                _downKeys.push(17);
            }
            if (_downKeys.indexOf(18) === -1) {
                _downKeys.push(18);
            }
            _mods[17] = true;
            _mods[18] = true;
        }
        var scope = getScope();
        if (asterisk) {
            for (var i = 0; i < asterisk.length; i++) {
                if (asterisk[i].scope === scope && (event.type === 'keydown' && asterisk[i].keydown || event.type === 'keyup' && asterisk[i].keyup)) {
                    eventHandler(event, asterisk[i], scope);
                }
            }
        }
        if (!(key in _handlers)) return;
        for (var _i = 0; _i < _handlers[key].length; _i++) {
            if (event.type === 'keydown' && _handlers[key][_i].keydown || event.type === 'keyup' && _handlers[key][_i].keyup) {
                if (_handlers[key][_i].key) {
                    var record = _handlers[key][_i];
                    var splitKey = record.splitKey;
                    var keyShortcut = record.key.split(splitKey);
                    var _downKeysCurrent = [];
                    for (var a = 0; a < keyShortcut.length; a++) {
                        _downKeysCurrent.push(code(keyShortcut[a]));
                    }
                    if (_downKeysCurrent.sort().join('') === _downKeys.sort().join('')) {
                        eventHandler(event, record, scope);
                    }
                }
            }
        }
    }
    function isElementBind(element) {
        return elementHasBindEvent.indexOf(element) > -1;
    }
    function hotkeys(key, option, method) {
        _downKeys = [];
        var keys = getKeys(key);
        var mods = [];
        var scope = 'all';
        var element = document;
        var i = 0;
        var keyup = false;
        var keydown = true;
        var splitKey = '+';
        if (method === undefined && typeof option === 'function') {
            method = option;
        }
        if (Object.prototype.toString.call(option) === '[object Object]') {
            if (option.scope) scope = option.scope; // eslint-disable-line
            if (option.element) element = option.element; // eslint-disable-line
            if (option.keyup) keyup = option.keyup; // eslint-disable-line
            if (option.keydown !== undefined) keydown = option.keydown; // eslint-disable-line
            if (typeof option.splitKey === 'string') splitKey = option.splitKey; // eslint-disable-line
        }
        if (typeof option === 'string') scope = option;
        for (; i < keys.length; i++) {
            key = keys[i].split(splitKey);
            mods = [];
            if (key.length > 1) mods = getMods(_modifier, key);
            key = key[key.length - 1];
            key = key === '*' ? '*' : code(key);
            if (!(key in _handlers)) _handlers[key] = [];
            _handlers[key].push({
                keyup: keyup,
                keydown: keydown,
                scope: scope,
                mods: mods,
                shortcut: keys[i],
                method: method,
                key: keys[i],
                splitKey: splitKey
            });
        }
        if (typeof element !== 'undefined' && !isElementBind(element) && window) {
            elementHasBindEvent.push(element);
            addEvent(element, 'keydown', function (e) {
                dispatch(e);
            });
            addEvent(window, 'focus', function () {
                _downKeys = [];
            });
            addEvent(element, 'keyup', function (e) {
                dispatch(e);
                clearModifier(e);
            });
        }
    }
    var _api = {
        setScope: setScope,
        getScope: getScope,
        deleteScope: deleteScope,
        getPressedKeyCodes: getPressedKeyCodes,
        isPressed: isPressed,
        filter: filter,
        unbind: unbind
    };
    for (var a in _api) {
        if (Object.prototype.hasOwnProperty.call(_api, a)) {
            hotkeys[a] = _api[a];
        }
    }
    if (typeof window !== 'undefined') {
        var _hotkeys = window.hotkeys;
        hotkeys.noConflict = function (deep) {
            if (deep && window.hotkeys === hotkeys) {
                window.hotkeys = _hotkeys;
            }
            return hotkeys;
        };
        window.hotkeys = hotkeys;
    }
    return hotkeys;
        }
		)
		;}
		}
        </script>
    <?php
    add_action('wp_head', 'tawhidurrahmandearthirtyeight');
    }