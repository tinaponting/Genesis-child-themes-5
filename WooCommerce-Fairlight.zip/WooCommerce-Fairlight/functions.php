<?php
/** Start the engine **/
require_once( get_template_directory() . '/lib/init.php' );

/** Child theme (do not remove) **/
define( 'CHILD_THEME_NAME', 'Fairlight Theme by Dinosaur Stew' );

/** Add Viewport meta tag for mobile browsers **/
add_action( 'genesis_meta', 'add_viewport_meta_tag' );
function add_viewport_meta_tag() {
    echo '<meta name="viewport" content="width=device-width, initial-scale=1.0"/>';
}

/** Enable HTML5 markup **/
add_theme_support( 'html5' );

//* Add support for custom background
add_theme_support( 'custom-background' );

/** Remove Right Header Area **/
unregister_sidebar( 'header-right' );

//* Unregister secondary sidebar
unregister_sidebar( 'sidebar-alt' );

/** Remove Layout Settings **/
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );
genesis_unregister_layout( 'sidebar-content-sidebar' );

/** Add support for 3-column footer widgets */
add_theme_support( 'genesis-footer-widgets', 3 );
 
/** Add Google Fonts */
add_action( 'genesis_meta', 'wpb_add_google_fonts', 5);

function wpb_add_google_fonts() {
		echo '<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic|Montserrat:400,700|Neuton:300,400,700,400italic" media="screen">';
}

/** Enqueue scripts and styles **/
add_action( 'wp_enqueue_scripts', 'custom_scripts_styles_mobile_responsive' );
function custom_scripts_styles_mobile_responsive() {

	wp_enqueue_script( 'beautiful-responsive-menu', get_stylesheet_directory_uri() . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0' );
	wp_enqueue_style( 'dashicons' );
	
	// If WooCommerce is installed, add Custom CSS for WooCommerce
	if ( class_exists( 'woocommerce' ) ) {
		wp_enqueue_style( 'custom-stylesheet', CHILD_URL . '/woo/woocommerce.css', array() );
	}
}

/** Add new image sizes */
add_image_size( 'featured-post-img', 245, 245, TRUE );

/** Customize the post info function */
add_filter( 'genesis_post_info', 'post_info_filter' );
function post_info_filter($post_info) {
if ( !is_page() ) {
    $post_info = '[post_date] [post_comments before="| "]';
    return $post_info;
}}

/** Remove post info and post meta from category pages */
add_action( 'genesis_before_entry', 'ds_remove_post_info_cat' );
function ds_remove_post_info_cat() {
	if ( is_category() ) {
		remove_action( 'genesis_entry_header', 'genesis_post_info', 12 );
		remove_action( 'genesis_entry_footer', 'genesis_post_meta' );
	}
}

/** Customize the post meta function */
add_filter( 'genesis_post_meta', 'post_meta_filter' );
function post_meta_filter($post_meta) {
if ( !is_page() ) {
    $post_meta = '[post_categories before="Categories : "] [post_tags before="Tagged : "]';
    return $post_meta;
}}

/**  Customize the credits  */
add_filter('genesis_footer_creds_text', 'custom_footer_creds_text');
function custom_footer_creds_text() {
    echo '<div class="creds"><p>';
    echo 'Copyright &copy; ';
    echo date('Y');
    echo ' &middot; Fairlight Wordpress Theme by <a href="https://example.com" target="_blank">Example</a>';
    echo '</p></div>';

}

//* Force excerpts on Category pages
add_action( 'genesis_before_loop', 'sk_author_pages' );
function sk_author_pages() {

	if ( is_category() ) {
		add_filter( 'genesis_pre_get_option_content_archive', 'sk_show_excerpts_cat' );
		add_filter( 'genesis_pre_get_option_content_archive_thumbnail', 'sk_show_post_image_cat' );
	}
}

function sk_show_excerpts_cat() {

	return 'excerpts';
	
}

function sk_show_post_image_cat() {
	return '1';
}


//* Modify the Excerpt read more link
add_filter('excerpt_more', 'new_excerpt_more_cat');
function new_excerpt_more_cat($more) {

	return '... <a class="more-link" href="' . get_permalink() . '">Keep Reading</a>';

}

/** Customize search form input box text */
add_filter( 'genesis_search_text', 'sp_search_text' );
function sp_search_text( $text ) {
	return esc_attr( 'Type keyword and hit enter' );
}

/** Add Genesis Responsive Slider Default Values */
add_filter( 'genesis_responsive_slider_settings_defaults', 'ds_responsive_slider_defaults' );
function ds_responsive_slider_defaults( $defaults ) {
    $defaults = array(
        'slideshow_height' => 450,
        'slideshow_width' => 1024
    );
    return $defaults;
}

/** Register homepage widget areas */
genesis_register_sidebar( array(
	'id'          => 'home-top',
	'name'        => __( 'Home - Top', 'ds' ),
	'description' => __( 'This is the top section of the homepage.', 'ds' ),
) );
genesis_register_sidebar( array(
	'id'          => 'home-middle',
	'name'        => __( 'Home - Middle', 'ds' ),
	'description' => __( 'This is the middle section of the homepage.', 'ds' ),
) );
genesis_register_sidebar( array(
	'id'          => 'home-bottom',
	'name'        => __( 'Home - Bottom', 'ds' ),
	'description' => __( 'This is the bottom section of the homepage.', 'ds' ),
) );

//* Add support for additional color style options
add_theme_support( 'genesis-style-selector', array(
	'fairlight-purple' => __( 'purple', 'fairlight' ),
) );


//* Add Archive Settings option to Portfolio CPT
add_post_type_support( 'portfolio', 'genesis-cpt-archives-settings' );

//* Define custom image size for Portfolio images in Portfolio archive
add_image_size( 'be_portfolio', 285, 285, true );

/**
 * Portfolio Template for Taxonomies
 * 
 */
function be_portfolio_template( $template ) {
  if( is_tax( array( 'portfolio_category', 'portfolio_tag' ) ) )
	$template = get_query_template( 'archive-portfolio' );
  return $template;
}
add_filter( 'template_include', 'be_portfolio_template' );

add_action( 'pre_get_posts', 'be_change_portfolio_posts_per_page' );
/**
 * Change Posts Per Page for Portfolio Archive
 * 
 * @author Bill Erickson
 * @link http://www.billerickson.net/customize-the-wordpress-query/
 * @param object $query data
 *
 */
function be_change_portfolio_posts_per_page( $query ) {
	
	if( $query->is_main_query() && !is_admin() && is_post_type_archive( 'portfolio' ) ) {
		$query->set( 'posts_per_page', '10' );
	}

}

//* Remove default WooCommerce Styles
add_filter( 'woocommerce_enqueue_styles', 'dss_dequeue_styles' );
function dss_dequeue_styles( $enqueue_styles ) {

	unset( $enqueue_styles['woocommerce-general'] );
	return $enqueue_styles;

}

//* Add Theme Support for WooCommerce
add_theme_support( 'genesis-connect-woocommerce' );

//* Remove Related Products
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );

//* Remove Add to Cart on Archives
add_action( 'woocommerce_after_shop_loop_item', 'remove_add_to_cart_buttons', 1 );
function remove_add_to_cart_buttons() {

    remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart' );

}

//* Display 16 products per page
add_filter( 'loop_shop_per_page', create_function( '$cols', 'return 16;' ), 20 );
