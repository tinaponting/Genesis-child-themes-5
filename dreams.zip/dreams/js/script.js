// JavaScript Document
jQuery( function ( $ ) {
	$(".entry-content").fitVids();
	
	$('.nav-primary').attr('id', 'menu');
	$('.nav-primary').addClass('menu-min');
	
	//nambahspan
	$( "aside .widget .widget-wrap h4" ).wrapInner( "<span></span>");
	$( "body.category .archive-title" ).wrapInner( "<span></span>");

	//search
	$('#main-nav-search-link').click(function(){
		$('.search-div').show('1200');
	});

	$("*", document.body).click(function(event){
		// event.stopPropagation();
		var el = $(event.target);
		var gsfrm = $(el).closest('form');
		if(el.attr('id') !='main-nav-search-link' && el.attr('role') != 'search' && gsfrm.attr('role') != 'search'){
			$('.search-div').hide('1200');
		}
	});

	
});