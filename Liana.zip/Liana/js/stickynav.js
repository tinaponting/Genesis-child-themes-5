( function( window, $, undefined ) {
'use strict';

var stickyNavTop = $('header.site-header').offset().top + $('header.site-header').height();

var stickyNavTopback = $('header.site-header').offset().top + $('header.site-header').height()+ 400;
 
var stickyNav = function(){
var scrollTop = $(window).scrollTop();
      
if (scrollTop > stickyNavTop) { 
    $('header.site-header').addClass('sticky');
} else {
    $('header.site-header').removeClass('sticky'); 
}

if (scrollTop > stickyNavTopback) { 
    $('header.site-header').addClass('stickyback');
} else {
    $('header.site-header').removeClass('stickyback'); 
}

};
 
stickyNav();
 
$(window).scroll(function() {
    stickyNav();
});
})( this, jQuery );