(function($) {
  $( "body.home .wrap" ).addClass( "ready-fade" );
  
  $(window).scroll(function() {
    $(".ready-fade").each(function() {
      /* Check the location of each desired element */
      var objectBottom = $(this).offset().top + ($(this).height() / 4);
      var windowBottom = $(window).scrollTop() + $(window).innerHeight();
if (objectBottom < windowBottom) {
        if (!$(this).hasClass( "start-fade" )) {$(this).addClass( "start-fade" );}
      }
    });
  }); $(window).scroll();
  
})(jQuery);