<?php
/**
 * Template Name: Landing
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that other 'pages' on your WordPress site will use a different template. 
 *
 * @author Eclair Designs
 * @package Chloe
 * 
 */

//* Add custom body class to the head
add_filter( 'body_class', 'chloe_add_body_class' );
function chloe_add_body_class( $classes ) {

   $classes[] = 'chloe-landing';
   return $classes;
   
}

//* Force full width content layout
add_filter( 'genesis_site_layout', '__genesis_return_full_width_content' );
remove_action('genesis_footer', 'elle_footer_widget'); 
remove_action( 'genesis_header', 'genesis_header_markup_open', 5 );
remove_action( 'genesis_header', 'genesis_do_header' );
remove_action( 'genesis_header', 'genesis_header_markup_close', 15 );
remove_action('genesis_before_footer', 'alexa_posts', 11 );
remove_action('genesis_before_footer', 'alexa_bestposts', 12 );
remove_action( 'widgets_init', 'elle_extra_widgets' );
remove_action( 'genesis_before_header', 'genesis_do_nav' );
remove_action( 'widgets_init', 'elle_extra_widgets' );
remove_action( 'genesis_footer', 'eclairdesigns_footer' );
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );
remove_action( 'genesis_before_footer', 'genesis_footer_widget_areas' );
remove_action( 'genesis_footer', 'sp_custom_footer' );
remove_action( 'genesis_footer', 'genesis_footer_markup_open', 5 );
remove_action( 'genesis_footer', 'genesis_do_footer' );
remove_action( 'genesis_footer', 'genesis_footer_markup_close', 15 );
remove_action( 'genesis_nav_items', 'sws_social_icons', 10, 2 );
remove_action( 'wp_nav_menu_items', 'sws_social_icons', 10, 2 );
remove_action( 'genesis_entry_footer', 'single_post_social_share' );
remove_action( 'genesis_before_header', 'eclair_social_icons', 10 );
unregister_sidebar( 'header-right' );
genesis();