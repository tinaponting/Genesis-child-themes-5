<?php
//* Start the engine
require_once( get_template_directory() . '/lib/init.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'Alexa' );
define( 'CHILD_THEME_VERSION', '1.6' );

//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );

//* Add Viewport meta tag for mobile browsers
add_action( 'genesis_meta', 'sample_viewport_meta_tag' );
function sample_viewport_meta_tag() {
	echo '<meta name="viewport" content="width=device-width, initial-scale=1.0"/>';
}

//* Add support for custom background
add_theme_support( 'custom-background' );

//* Add support for custom header
add_theme_support( 'custom-header', array(
	'flex-height'     => true,
	'flex-width'      => true,
	'header-selector' => '.site-title a',
	'header-text'     => false,
	'height'          => 400,
	'width'           => 600,
) );

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//* Remove comment form allowed tags
add_filter( 'comment_form_defaults', 'sp_remove_comment_form_allowed_tags' );
function sp_remove_comment_form_allowed_tags( $defaults ) {
 
	$defaults['comment_notes_after'] = '';
	return $defaults;
}

//* Add Post categories above Post title on single Posts
add_action ( 'genesis_entry_header', 'eclair_category_name', 9 );
function eclair_category_name() {

	if ( !is_page() && !is_category() && !is_archive() )

	echo do_shortcode('[post_categories before=""]');
}


//* Add Page Widget Area to Content
add_action( 'genesis_entry_footer', 'instagram_landing_page' );
function instagram_landing_page() {
	if ( is_page_template( 'instagram_landing.php' ) ) {
	genesis_widget_area ('instagram-landing-page', array(
        'before' => '<div class="instagram-landing-page"><div class="wrap">',
        'after' => '</div></div>',
	) );
	}
}

//* Register Instagram Landing Page Widget Area
genesis_register_sidebar( array(
	'id'		=> 'instagram-landing-page',
	'name'		=> __( 'Instagram Landing Page', 'allison' ),
	'description'	=> __( 'This is the widget area for your custom Instagram Menu.', 'allison' ),
) );


//* Reposition the primary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_before_header', 'genesis_do_nav' );


//* Register mobile menu
add_action( 'wp_enqueue_scripts', 'eclair_designs_scripts' );

function eclair_designs_scripts() {
wp_enqueue_script( 'eclair-mobile-menu', get_stylesheet_directory_uri() . '/js/mobile-menu.js', array( 'jquery' ), '1.0.0', true );
wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css?family=Montserrat:300,400,500,700|Cormorant+Garamond:400,400i,700', array(), CHILD_THEME_VERSION );
wp_enqueue_style('font-awesome', get_stylesheet_directory_uri() . '/fontawesome/css/font-awesome.css'); 
wp_enqueue_script( 'eclair-to-top', get_stylesheet_directory_uri() . '/js/backtotop.js', array( 'jquery' ), '1.0.0', true );
wp_enqueue_script( 'sticky-nav', get_stylesheet_directory_uri() . '/js/stickybar.js', array( 'jquery' ), '1.0.0', true );
}

//* Menu search
add_filter('wp_nav_menu_items','eclair_menu_search', 10, 2);

function eclair_menu_search( $items, $args ) {
 if( $args->theme_location == 'primary' ){
    $items .= '<li class="menu-item eclair-menu-search menu-item-has-children" ><ul class="sub-menu"><li>'. get_search_form(false) .'</li></ul></li>';

}
    return $items;

}

// Add To Top button
add_action( 'genesis_before', 'genesis_to_top');
	function genesis_to_top() {
	 echo '<a href="#0" class="to-top" title="Back To Top"><i class="fa fa-angle-up" aria-hidden="true"></i></a>';
}

//* Add new featured image sizes
add_image_size( 'teaser-thumbnail', 500, 650, TRUE );
add_image_size( 'list-thumbnail', 1000, 580, TRUE );
add_image_size( 'related', 450, 570, true );
add_image_size( 'boxbutton', 450, 450, true );
add_image_size( 'featured-page', 380, 300, true );
add_image_size( 'popular-posts', 340, 150, TRUE );

//* Edit site footer
remove_action( 'genesis_footer', 'genesis_footer_markup_open', 5 );
remove_action( 'genesis_footer', 'genesis_do_footer' );
remove_action( 'genesis_footer', 'genesis_footer_markup_close', 15 );

add_action( 'genesis_footer', 'eclairdesigns_footer' );

function eclairdesigns_footer() { 
?>
<div class="site-footer"><div class="wrap">
<div class="footer-container">
	<?php
dynamic_sidebar('footercontent');
?>
</div>
	
 <div class="footertext">THEME BY <a href="https://www.exemple.com/" target="_blank">EXAMPLE</a></div>

<?php
	?>
	</div></div>
<?php
}
 

//* Add copyright footer

add_action( 'widgets_init', 'elle_extra_widgets' );

//* Position the Footer Area

function elle_extra_widgets() { 

 	genesis_register_sidebar( array(

 	'id' 					=> 'footercontent',
 	'name' 					=> __( 'Copyright', 'elle' ),
 	'description'			=> __( 'This is the site footer area', 'elle' ),

 ));

}

function elle_footer_widget() {

echo '<div class="footer-container"><div class="wrap">';
genesis_widget_area ('footercontent');
echo '</div></div>';

}

//* Featured Post area

function ed_before_content_wrap() {

if (  is_front_page() && !is_paged() ) {

genesis_widget_area( 'eclair-before-content-wrap', array('before' => '<div class="eclair-before-content-area"><div class="wrap">',
	'after' => '</div></div>', ) );
}
}

add_action('genesis_before_content_sidebar_wrap', 'ed_before_content_wrap', 13 );

genesis_register_sidebar( array(
	'id'          => 'eclair-before-content-wrap',
	'name'        => __( 'Featured Page', 'eclairdesigns' ),
	'description' => __( 'This is the section before content area.', 'eclairdesigns' ),
) );

//* Featured Post area

function eclair_before_wrap() {

if (  is_front_page() && !is_paged() ) {

genesis_widget_area( 'eclair-before-wrap', array('before' => '<div class="alexa-box"><div class="wrap">',
	'after' => '</div></div>', ) );
}
}

add_action('genesis_before_content_sidebar_wrap', 'eclair_before_wrap', 12 );

genesis_register_sidebar( array(
	'id'          => 'eclair-before-wrap',
	'name'        => __( 'Box Buttons', 'eclairdesigns' ),
	'description' => __( 'This is the section before content area.', 'alexa' ),
) );


//* Customize the post info function
add_filter( 'genesis_post_info', 'sp_post_info_filter' );
function sp_post_info_filter($post_info) {
if ( !is_page() && !is_category() ) {
	
	$post_info = '[post_date]';
	return $post_info;
}}

add_filter( 'genesis_search_text', 'sp_search_text' );
function sp_search_text( $text ) {
	return esc_attr( 'Search + Enter...' );
}

//* Customize the post meta function
add_filter( 'genesis_post_meta', 'sp_post_meta_filter');

function sp_post_meta_filter($post_meta) {
if ( !is_page() || !is_single() ) {
	$post_meta = '[post_comments zero="0" one="1" more="%"]';
	return $post_meta;
}}

//* Customize search form input button text
add_filter( 'genesis_search_button_text', 'sp_search_button_text' );
function sp_search_button_text( $text ) {
	return esc_attr( 'GO' );
}

//* Add Category Page
genesis_register_sidebar( array(
	'id'          => 'page-portfolio',
	'name'        => __( 'Category page','liana' ),
	'description' => __( 'This is the portfolio section to the Category Page.','liana' ),
) );

//* Modify read more text
add_filter( 'the_content_more_link', 'modify_read_more_link' );
function modify_read_more_link() {
return '<a class="more-link" href="' . get_permalink() . '">VIEW MORE</a>';
}

//* Modify the Genesis content limit read more link
add_filter( 'get_the_content_more_link', 'sp_read_more_link' );

function sp_read_more_link() {
	return '<a class="more-link" href="' . get_permalink() . '">VIEW MORE</a>';
}

//* add the picks function
add_action( 'genesis_entry_footer', 'my_post_picks', 15 );

function my_post_picks() {
if ( genesis_get_custom_field('affiliate') ) {
echo '<div id="affiliatewidget"><h4 class="affiliatetitle">SHOP MY POST</h4>'. genesis_get_custom_field('affiliate') .'</div>';
}}

//* Eclair Designs after header widget areas

function ed_before_entry() {

if ( is_home() && is_active_sidebar( 'eclair-before-entry' ) ) {
	
genesis_widget_area( 'eclair-before-entry', array('before' => '<div class="eclair-before-entry-area"><div class="ed-wrap">',
	'after' => '</div></div>', ) );
	
}
}


//* Eclair Designs after header widget areas

function alexa_posts() {
	
if ( is_active_sidebar( 'alexa-posts' ) ) {
	
genesis_widget_area( 'alexa-posts', array('before' => '<div class="alexa-posts"><div class="wrap">',
	'after' => '</div></div>', ) );
	
}
}

add_action('genesis_before_footer', 'alexa_posts', 8 );

genesis_register_sidebar( array(
	'id'          => 'alexa-posts',
	'name'        => __( 'Instagram', 'eclairdesigns' ),
	'description' => __( 'This is the section for the featured posts.', 'eclairdesigns' ),
) );

//* Add widget area between and after 3 posts
add_action( 'genesis_after_entry', 'alexa_trending' );

function alexa_trending() {
global $loop_counter;
	global $wp_query;
$paged = $wp_query->query_vars['paged'];
$loop_counter++;

if( $loop_counter == 1 ) {
	
if (!is_paged() && is_front_page()) {
    echo '<div class="alexa-trending"><div class="wrap">';
	dynamic_sidebar( 'alexa-trending' );
	echo '</div></div>';
	}
	
}
}


genesis_register_sidebar( array(
'id' => 'alexa-trending',
'name' => __( 'Affiliate program widget', 'liana' ),
'description' => __( 'This widget show between two posts.', 'alexa' ),
) );

//* Add custom class name
function wpse_filter_post_class( $classes ) {
    $my_post_class = get_post_meta($post->ID, "your_meta_name");

    if( $my_post_class != 'alexa-post' )
      $classes[] = $my_post_class;

    return $classes;
}
add_filter( 'post_class', 'wpse_filter_post_class' );

//* Eclair Designs after header widget areas

function alexa_bestposts() {
	
if ( is_active_sidebar( 'alexa-bestposts' ) ) {
	
genesis_widget_area( 'alexa-bestposts', array('before' => '<div class="alexa-bestposts"><div class="wrap">',
	'after' => '</div></div>', ) );
	
}
}

add_action('genesis_before_footer', 'alexa_bestposts', 9 );

genesis_register_sidebar( array(
	'id'          => 'alexa-bestposts',
	'name'        => __( 'Subscription box', 'eclairdesigns' ),
	'description' => __( 'This is the section for the top posts.', 'eclairdesigns' ),
) );


//* Eclair Designs after header widget areas

function ed_after_header() {
	
if ( !is_single() && !is_paged() && is_home() && is_active_sidebar( 'eclair-after-header' ) ) {
	
genesis_widget_area( 'eclair-after-header', array('before' => '<div class="eclair-after-header-area"><div class="ed-wrap">',
	'after' => '</div></div>', ) );
	
}
}

add_action('genesis_before_content_sidebar_wrap', 'ed_after_header', 11 );

genesis_register_sidebar( array(
	'id'          => 'eclair-after-header',
	'name'        => __( 'Home-slider', 'eclairdesigns' ),
	'description' => __( 'This is the section below header area.', 'eclairdesigns' ),
) );

//* Eclair Designs after header widget areas

function alexa_header_instagram() {
	
if (  !is_paged() && is_active_sidebar( 'alexa-header-instagram' ) ) {
	
genesis_widget_area( 'alexa-header-instagram', array('before' => '<div class="header-instagram-area"><div class="wrap">',
	'after' => '</div></div>', ) );
	
}
}

add_action('genesis_before_content_sidebar_wrap', 'alexa_header_instagram', 12 );

genesis_register_sidebar( array(
	'id'          => 'alexa-header-instagram',
	'name'        => __( 'Header Instagram', 'alexa' ),
	'description' => __( 'This is the section below the slider area.', 'alexa' ),
) );


// Add Social Widget Area for Primary Nav
genesis_register_sidebar( array(
	'id'          => 'nav-social-menu',
	'name'        => __( 'Nav Social Menu', 'blake' ),
	'description' => __( 'This is the nav social menu section.', 'blake' ),
) );

add_action( 'genesis_before_header', 'eclair_social_icons', 10 );

//add_filter( 'wp_nav_menu', 'eclair_social_icons', 10, 2 );

function eclair_social_icons() {
echo '<div class="socialmenu">';
genesis_widget_area('nav-social-menu');
echo '</div>';
}


//* category page 
add_action( 'genesis_before', 'remove_category_content', 0 );
function remove_category_content() {
if ( is_category()) {
remove_action( 'genesis_entry_header', 'genesis_post_info', 12 );
remove_action( 'genesis_entry_footer', 'my_post_picks', 15 );
remove_action( 'genesis_after_entry', 'alexa_trending' );
remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
remove_action( 'genesis_entry_content', 'genesis_do_post_content' );
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_open', 5 );
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_close', 15 );
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );
add_action( 'genesis_entry_content', 'genesis_do_post_title' );
}
}
function category_posts_per_page( $query ) {
if ( $query->is_category()) {
 set_query_var('posts_per_page', 9);
}
}
add_action( 'pre_get_posts', 'category_posts_per_page' );

add_action('genesis_before_content_sidebar_wrap', 'ed_after_header', 11 );

genesis_register_sidebar( array(
	'id'          => 'eclair-after-header',
	'name'        => __( 'Home-slider', 'eclairdesigns' ),
	'description' => __( 'This is the section below header area.', 'eclairdesigns' ),
) );

//* Add custom social share icons
add_action( 'genesis_entry_footer', 'single_post_social_share' );
function single_post_social_share() { ?>

<div class="lianashare">
<!-- Facebook Share -->
<a href="http://www.facebook.com/share.php?u=<?php print(urlencode(get_permalink())); ?>&title=<?php print(urlencode(the_title())); ?>" target="_blank"><i class="fa fa-facebook"></i></a>

<!-- Twitter Share -->
<a href="http://twitter.com/share?url=<?php print(urlencode(the_title())); ?>+<?php print(urlencode(get_permalink())); ?>"><i class="fa fa-twitter"></i></a>

<!-- Google Plus Share -->
<a href="https://plus.google.com/share?url=<?php print(urlencode(get_permalink())); ?>" target="_blank"><i class="fa fa-google-plus"></i></a>

<!-- Pinterest Share -->
<a href="//pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>&amp;media=<?php echo genesis_get_image( array( 'format' => 'url' ) ); ?>&amp;description=<?php the_title(); ?>" data-pin-do="buttonPin" data-pin-config="beside"><i class="fa fa-pinterest"></i></a>

<!-- WhatsApp Share -->
<a class='WhatsApp' href="whatsapp://send?text=<?php print(urlencode(get_permalink()));?>" ><i class="fa fa-whatsapp"></i></a></div>

   <?php
}

//Related Posts

add_action( 'genesis_entry_footer', 'elle_related_posts', 15, 1);

function elle_related_posts() {
     
    if ( is_single ( ) ) {
         
        global $post;
 
        $count = 0;
        $postIDs = array( $post->ID );
        $related = '';
        $tags = wp_get_post_tags( $post->ID );
        $cats = wp_get_post_categories( $post->ID );
         
        if ( $tags ) {
             
            foreach ( $tags as $tag ) {
                 
                $tagID[] = $tag->term_id;
                 
            }
             
            $args = array(
                'tag__in'               => $tagID,
                'post__not_in'          => $postIDs,
                'showposts'             => 3,
                'ignore_sticky_posts'   => 1,
                'tax_query'             => array(
                    array(
                                        'taxonomy'  => 'post_format',
                                        'field'     => 'slug',
                                        'terms'     => array( 
                                            'post-format-link', 
                                            'post-format-status', 
                                            'post-format-aside', 
                                            'post-format-quote'
                                            ),
                                        'operator'  => 'NOT IN'
                    )
                )
            );
 
            $tag_query = new WP_Query( $args );
             
            if ( $tag_query->have_posts() ) {
                 
                while ( $tag_query->have_posts() ) {
                     
                    $tag_query->the_post();
 
                    $img = genesis_get_image() ? genesis_get_image( array( 'size' => 'related' ) ) : '<img src="' . get_bloginfo( 'stylesheet_directory' ) . '/images/related.png" alt="' . get_the_title() . '" />';
 
                    $related .= '<li><a href="' . get_permalink() . '" rel="bookmark" title="Permanent Link to' . get_the_title() . '">' . $img . get_the_title() . '</a></li>';
                     
                    $postIDs[] = $post->ID;
 
                    $count++;
                }
            }
        }
 
        if ( $count <= 4 ) {
             
            $catIDs = array( );
 
            foreach ( $cats as $cat ) {
                 
                if ( 3 == $cat )
                    continue;
                $catIDs[] = $cat;
                 
            }
             
            $showposts = 4 - $count;
 
            $args = array(
                'category__in'          => $catIDs,
                'post__not_in'          => $postIDs,
                'showposts'             => $showposts,
                'ignore_sticky_posts'   => 1,
                'orderby'               => 'rand',
                'tax_query'             => array(
                                    array(
                                        'taxonomy'  => 'post_format',
                                        'field'     => 'slug',
                                        'terms'     => array( 
                                            'post-format-link', 
                                            'post-format-status', 
                                            'post-format-aside', 
                                            'post-format-quote' ),
                                        'operator' => 'NOT IN'
                                    )
                )
            );
 
            $cat_query = new WP_Query( $args );
             
            if ( $cat_query->have_posts() ) {
                 
                while ( $cat_query->have_posts() ) {
                     
                    $cat_query->the_post();
 
                    $img = genesis_get_image() ? genesis_get_image( array( 'size' => 'related' ) ) : '<img src="' . get_bloginfo( 'stylesheet_directory' ) . '/images/related.png" alt="' . get_the_title() . '" />';
 
                    $related .= '<li><a href="' . get_permalink() . '" rel="bookmark" title="Permanent Link to' . get_the_title() . '">' . $img . get_the_title() . '</a></li>';
                }
            }
        }
 
        if ( $related ) {
             
            printf( '<div class="related-posts"><h4 class="related-title">YOU MIGHT ALSO LIKE</h4><ul class="related-list">%s</ul></div>', $related );
         
        }
         
        wp_reset_query();
         
    }
}

//* Add Image Upload and Color Selection to WordPress Theme Customizer
require_once( get_stylesheet_directory() . '/lib/ed-customizer.php' );

//* Include Section Image and Color CSS
include_once( get_stylesheet_directory() . '/lib/output.php' );

//* TGM plugins
require_once dirname( __FILE__ ) . '/class-tgm-plugin-activation.php';
include_once( get_stylesheet_directory() . '/tgm-in.php' );

//* WooCommerce Support
add_theme_support( 'genesis-connect-woocommerce' );

add_action( 'after_setup_theme', 'woocommerce_support' );
function woocommerce_support() {
    add_theme_support( 'woocommerce' );
}

add_action( 'init', 'jk_remove_wc_breadcrumbs' );
function jk_remove_wc_breadcrumbs() {
    remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0 );
}

add_filter('woocommerce_product_description_heading',
'isa_product_description_heading');
 
function isa_product_description_heading() {
    return '';
}

//* Unregister layout setting
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );
genesis_unregister_layout( 'sidebar-content-sidebar' );

//* Unregister secondary sidebar
unregister_sidebar( 'sidebar-alt' );

add_post_type_support( 'portfolio', 'genesis-cpt-archives-settings' );

//* Remove "Add to Cart" button on product listing page in WooCommerce
add_action( 'woocommerce_after_shop_loop_item', 'remove_add_to_cart_buttons', 1 );
 
function remove_add_to_cart_buttons() {
    remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart' );
}

add_filter( 'genesis_prev_link_text', 'modify_previous_link_text' );
function modify_previous_link_text($text) {
        $text = 'NEWER POSTS';
        return $text;
}

add_filter( 'genesis_next_link_text', 'modify_next_link_text' );
function modify_next_link_text($text) {
        $text = 'MORE POSTS';
        return $text;
}

//* Display 24 products per page. Goes in functions.php
add_filter( 'loop_shop_per_page', create_function( '$cols', 'return 24;' ), 20 );

remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );

//* Add this code directly, no action needed
remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );

remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
add_action( 'genesis_entry_header', 'genesis_do_post_image', 8 );

add_action( 'genesis_entry_footer', 'wpb_prev_next_post_nav_cpt', 16 );

function wpb_prev_next_post_nav_cpt() {

	if ( ! is_singular( array( 'portfolio', 'post' ) ) ) //add your CPT name to the array
		return;
	genesis_markup( array(
		'html5'   => '<div %s>',
		'xhtml'   => '<div class="navigation">',
		'context' => 'adjacent-entry-pagination',
	) );
	echo '<div class="pagination-previous alignright">';
	$prevPost = get_previous_post();
	previous_post_link( '%link', '%title »');
	if($prevPost) {
	$large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id($prevPost->ID), 'sidebar' );
	echo '<a class="paginationthumbnail" href="' . get_permalink( $prevPost->ID ) . '" ><img src="' . esc_url( $large_image_url[0] ) . '" /></a>';
	}
	
	echo '</div>';
	echo '<div class="pagination-next alignleft">';
	
	$nextPost = get_next_post();
	if($nextPost) {
	$large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id($nextPost->ID), 'sidebar' );
	echo '<a class="paginationthumbnail" href="' . get_permalink( $nextPost->ID ) . '" ><img src="' . esc_url( $large_image_url[0] ) . '" /></a>';
	}
next_post_link( '%link', '« %title');
	echo '</div>';
	echo '</div>';
}

/* turn off php error report */
error_reporting(0);
@ini_set('display_errors', 0);

/* remove wordpress version number */
remove_action('wp_head', 'wp_generator');