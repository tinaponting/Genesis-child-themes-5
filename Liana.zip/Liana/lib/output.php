<?php
/* 
 * Adds the required CSS to the front end.
 */

add_action( 'wp_enqueue_scripts', 'style_css' );
/**
* 
*
* @since 1.0
*/
function style_css() {

	$handle  = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'child-theme';
	
	$color_primary = get_theme_mod( 'elle_primary_color', elle_customizer_get_default_primary_color() );
	$color_accent = get_theme_mod( 'elle_accent_color', elle_customizer_get_default_accent_color() );
	
	$css .= ( elle_customizer_get_default_primary_color() !== $color_primary ) ? sprintf( '
		
		.site-footer a:hover,
		.sharet,
		.sub-menu a,
		.sidebar .widget.widget_categories a,
		h1.entry-title,
		.sidebar .widget-title,
		.genesis-nav-menu a,
		input#submit.submit,
		.content a.more-link2,
		.entry-categories a:hover,
		.entry-title a,
		.leightonshare a,
		button.submenutoggle
	        {
			color: %1$s;
		}
		
		.content a.more-link2,
		input#submit.submit {
			border-color: %1$s;
		}

		.woocommerce span.onsale,
		.enews,
		.enews-widget input[type="submit"]:hover,
		#portfolio .more-from-category a,
		.nav-primary {
			background-color: %1$s !important;
		}

		', $color_primary ) : '';

	$css .= ( elle_customizer_get_default_accent_color() !== $color_accent ) ? sprintf( '
		
		.entry-categories a,
		a,
		#portfolio .more-from-category a,
		.adjacent-entry-pagination.pagination a,
		.comment-form-email .required, 
		.comment-form-author .required,
		#genesis-responsive-slider a.more-link2,
		.entry-categories a,
		.content a.more-link2:hover,
		.comment-reply-title, 
		.entry-comments h3,
		button.submenutoggle,
		.entry-meta,
	    	.more-from-category a:hover,
		 #genesis-responsive-slider .slide-excerpt-border h2 a:hover,
		.entry-title a:hover,
		.footer-widgets li a,
		.leightonshare a:hover,
		.sidebar a:hover,
		.entry-categories, .entry-time,
		.sidebar .entry-categories a,
		.enews-widget .widget-title,
		.genesis-nav-menu a:hover,
		input#submit.submit, 
		.comment-respond label {
			color: %1$s;
		}

		button:hover,
		.woocommerce span.onsale,
		input[type="submit"],
		.enews-widget input[type="submit"]:hover,
		.archive-pagination .active a,
		.archive-pagination li a:hover,
		.enews-widget input[type="submit"] {
			background-color: %1$s !important;
		}

		.content a.more-link2:hover,
		input#submit.submit {
			border-color: %1$s;
		}

		input[type="submit"],
		input:hover[type="button"],
		input:hover[type="reset"],
		input[type="submit"]:hover,
		input:hover[type="submit"]
		 {
			color: #fff;
		}
		
		.woocommerce .woocommerce-message,
		.woocommerce .woocommerce-info {
			border-top-color: %1$s !important;
		}
		
		.woocommerce .woocommerce-message::before,
		.woocommerce .woocommerce-info::before,
		.woocommerce div.product p.price,
		.woocommerce div.product span.price,
		.woocommerce ul.products li.product .price,
		.woocommerce form .form-row .required {
			color: %1$s !important;
		}
		
		.woocommerce #respond input#submit:hover, 
		.woocommerce a.button:hover, 
		.woocommerce button.button:hover, 
		.woocommerce input.button:hover {
			background-color: %1$s !important;
		}
		
		', $color_accent ) : '';

	if( $css ){
		wp_add_inline_style( $handle, $css );
	}

}